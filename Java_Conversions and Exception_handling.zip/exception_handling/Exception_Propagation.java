package com.test.exception_handling;

public class Exception_Propagation 
{
	static void method3()
	
	{
		System.out.println("");
		System.out.println("In method3 find the length of the null String");
		String s=null;
		System.out.println("String null length is : "+s.length());
		
	}
	static void method2()
	{
		System.out.println(" ");
		System.out.println("Calling method3 by method2");
		method3();
		
	}
	static void method1()
	{
		try
		{
			System.out.println("Calling method2 by method1");
			method2();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Exception Propagation - calling chain method ");
		System.out.println("");
		System.out.println("NOte :");
		System.out.println("1.By default Unchecked Exceptions are forwarded in calling chain (propagated).");
		System.out.println("2. By default, Checked Exceptions are not forwarded in calling chain (propagated).");
		System.out.println("");
		Exception_Propagation obj=new Exception_Propagation ();
		obj.method1();
		
	}

}
