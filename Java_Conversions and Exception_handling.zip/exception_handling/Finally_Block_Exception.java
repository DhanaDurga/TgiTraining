	package com.test.exception_handling;
	
	public class Finally_Block_Exception {
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("Finally -Block");
			System.out.println("Rule -1 :For each try block there can be zero or more catch blocks, but only one finally block.");
			System.out.println("Rule -2 :The finally block will not be executed if the program exits (either by calling System.exit() or by causing a fatal error that causes the process to abort).");
			System.out.println("Rule -3 :Finally block is always executed ,if the program does not throw any exception");
			System.out.println("");
			try
			{
				System.out.println("Inside try block");  
				  
		        //below code throws divide by zero exception  
		       int data=25/0;    
		       System.out.println(data);    
		      }   
		  
		      //handles the Arithmetic Exception / Divide by zero exception  
		      catch(ArithmeticException e)
			{  
		        System.out.println("Exception handled");  
		        System.out.println(e);  
		      }   
		
			finally
			{System.out.println("");
				System.out.println("finally block is always executed");
			}
		}
	
	}
