package com.test.exception_handling;


import java.util.Scanner;

public class Arithmatic_Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter two numbers to perform Division operation");
		int number=sc.nextInt();
		int divisor=sc.nextInt();
		try
		{
			double ans=number/divisor;
			System.out.println("The answer is : "+ans);
		}
		catch(ArithmeticException e)
		{
		System.out.println(e);	
		}
		
		System.out.println("Number not divided by 0");

	}

}
