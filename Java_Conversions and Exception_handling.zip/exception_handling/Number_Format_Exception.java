package com.test.exception_handling;

public class Number_Format_Exception 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Number Format Exception");
		System.out.println("If you don't have numbers in string literal, calling Integer.parseInt() or Integer.valueOf() methods throw NumberFormatException.");
		String s="dhana";
		String n="1234";
		try
		{
			System.out.println("");
			Integer t=Integer.valueOf(n);
			System.out.println("Number String to int : "+t);
			int i=Integer.parseInt(s);
			System.out.println("Character String to int : "+i);
		}
		catch(NumberFormatException e)
		{	
			
			System.out.println(e);
		}
		System.out.println("Character String "+s + " not  convert to int ");
		System.out.println(" ");
		System.out.println("Using Exception Handling the rest of the code is executed");
	
	}

}
