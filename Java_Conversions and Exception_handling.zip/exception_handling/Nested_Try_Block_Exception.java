package com.test.exception_handling;

public class Nested_Try_Block_Exception 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		try
		{
			System.out.println("Main try block");
			
			try
			{
				System.out.println("Inner try block 1");
				System.out.println("Perform to find null String length");
				String s=null;
				System.out.println("String length is : "+s.length());
				try
				{
					System.out.println("");
					System.out.println("Inner try block 2");
					System.out.println("Perform a integer divide by zero");
					int a=45/0;
					System.out.println("The answer (45/0) is : "+a);
				}
				catch(NullPointerException e)
				{
					System.out.println("Inner try block2 catch");
					System.out.println(e);
				}
				
				
			}
			
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println(e);
				System.out.println("Inner try block1 -catch");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("Main try- catch block");
		}
finally
{
	System.out.println(" ");
	System.out.println("Important");
	System.out.println("When any try block does not have a catch block for a particular exception, then the catch block of the outer (parent) try block are checked for that exception, "+"\r\n"+"and if it matches, the catch block of outer try block is executed.\r\n"
			+ "\r\n"
			+ "If none of the catch block specified in the code is unable to handle the exception, then the Java runtime system will handle the exception."+"\r\n"+" Then it displays the system generated message for that exception.");
}
	}

}
