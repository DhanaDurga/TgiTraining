package com.test.exception_handling;

public class ArrayIndex_outOfBound_Exception 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try
		{
			System.out.println("ArrayIndexOutOfBounds Exception");
			System.out.println(" ");
			System.out.println("Array size is : int a[]=new int[5]; ");
			System.out.println(" If assign value in a[7]=30; means ,");
			int a[]=new int[5];  
			a[7]=30; //ArrayIndexOutOfBoundsException  
		}
		catch(ArrayIndexOutOfBoundsException e)
		
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("");
			System.out.println("When an array exceeds to it's size, the ArrayIndexOutOfBoundsException occurs. ");
		}
		

	}

}
