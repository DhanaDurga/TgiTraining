package com.test.exception_handling;

public class Null_Pointer_Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1=null;
		String str2="dhana";
		System.out.println("Null_Pointer_Exception");
		System.out.println("If we have a null value in any variable, performing any operation on the variable throws a NullPointerException.");
		System.out.println(" ");
		System.out.println("Concat a String with null");
		try
		{
			
			System.out.println("String with \"Welcome\" : "+(str2+"Welcome"));
			System.out.println("String with null String : "+(str1+str2));
			System.out.println(" ");
			System.out.println("str2.length = "+ str2.length());
			System.out.println("str1.length = "+ str1.length());
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
		finally
		{
			
		}
	}

}
