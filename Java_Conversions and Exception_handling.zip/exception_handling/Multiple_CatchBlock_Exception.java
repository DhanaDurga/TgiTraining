package com.test.exception_handling;

public class Multiple_CatchBlock_Exception 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try
		{
			System.out.println("Multiple Catch Block");
			System.out.println("");
			System.out.println("1.At a time only one exception occurs and at a time only one catch block is executed.");
			System.out.println("2.All catch blocks must be ordered from most specific to most general.");
			System.out.println(" ");
			System.out.println("First occured Exception block is invoked");
			String s=null;  
            System.out.println(s.length());
             int a[]=new int[5];    
            
             System.out.println(a[10]);  
             a[5]=30/0;    
			 
         }    
            catch(ArithmeticException e)  
               {  
                System.out.println("Arithmetic Exception occurs");  
               }    
            catch(ArrayIndexOutOfBoundsException e)  
               {  
                System.out.println("ArrayIndexOutOfBounds Exception occurs");  
               }    
            catch(Exception e)  
               {  
                System.out.println("Parent Exception occurs");  
               }             
            System.out.println("");    
            System.out.println("If didn't provide the corresponding exception type, the catch block containing the parent exception class Exception will invoked.");            		
	}
	}

