package com.test.conversionsMethods;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Date_Timestamp_Conversion
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Date to Timestamp conversion");
		System.out.println("");
		System.out.println("Print the time without format(view millisec)");
		Date date = new Date();  
        Timestamp ts=new Timestamp(date.getTime());  
        System.out.println(ts);      
		Date date1 = new Date();  
        Timestamp ts1=new Timestamp(date1.getTime());  
        System.out.println("Print the date and time after format ");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        System.out.println(formatter.format(ts1));    
        System.out.println(" ");
        System.out.println("Timestamp to Date Conversion");
         ts=new Timestamp(System.currentTimeMillis()); 
         ts1=new Timestamp(System.currentTimeMillis());
        Date date2=new Date(ts.getTime());  
        Date date3=ts1;
        System.out.println(date2); 
        System.out.println("The Timestamp class extends Date class. So, you can directly assign instance of Timestamp class into Date");
                System.out.println(date3);
        
                  
	}

}
