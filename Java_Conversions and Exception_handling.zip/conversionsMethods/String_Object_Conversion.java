package com.test.conversionsMethods;

public class String_Object_Conversion 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String res;
		System.out.println("String to Object_Conversion");
		System.out.println("Create object for a class and stored String value\"Hello\" .");
		String str="Hello";
		Object obj=str;
		System.out.println("After conversion object data is : "+obj);
		System.out.println(" ");
		System.out.println("Object to String_Conversion");
		System.out.println("Using toString() and String.valueOf()");
		res=obj.toString();
		System.out.println("obj.toString() => "+res);
		res=String.valueOf(obj);
		res=res+" Welcome All .";
		System.out.println("String.valueOf(obj)concat with \"Welcome All\"; => "+res);;
		
		System.out.println("");
		System.out.println("String and stringBuilder object Conversion");
		StringBuilder sb = new StringBuilder(res);
		System.out.println("Convert the StringBuiler data to String using toString() : "+sb.toString());
		sb.reverse();
		System.out.println("Convert the StringBuiler data to String using String.valueOf() after reverse process : "+String.valueOf(sb));
		

	}

}
