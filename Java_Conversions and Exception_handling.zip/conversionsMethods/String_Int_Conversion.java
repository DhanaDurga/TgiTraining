package com.test.conversionsMethods;

import java.util.Scanner;

public class String_Int_Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter your name and rollno ");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		int rollno=sc.nextInt();
		String scholarship="2000";
		int clgid=5110;
		System.out.println("Student Details");
		System.out.println("Name : "+name);
		System.out.println("Rollno : "+rollno);
		System.out.println("College Id : "+clgid);
		System.out.println("Scholarship amount : "+scholarship);
		System.out.println(" ");
		System.out.println("1.String to Int Conversion");
		System.out.println("  ");
		System.out.println("String scholarship amount is increased by 1000.");
		System.out.println("The String scholarship is concat with 1000 we get");
		Integer amount=Integer.valueOf(scholarship+1000);
		System.out.println(amount);
		int intscholar=Integer.parseInt(scholarship);
		System.out.println("Convert String scholarship amount to Integer intscholar : "+intscholar);
		System.out.println("After conversion that int value is concat with 1000 we get");
		System.out.println(intscholar+1000);
		System.out.println(" ");
		
		
		System.out.println("2.Int to String Conversion");
		System.out.println("  ");
		//System.out.println("Before conversion the rollno of the student concat with string \"CSE\" is : "+(rollno+"CSE"));
		System.out.println("Before conversion the rollno of the student concat with number 100  : "+(rollno+100));
		System.out.println("The integer student rollno is changed to string format.");
		String roll=String.valueOf(rollno);
		System.out.println("After conversion the rollno of the student concat with number 100  : "+(roll+100));
		//System.out.println("After conversion the rollno of the student concat with string \"CSE\" is : "+(roll+"CSE"));
		System.out.println(" ");
		System.out.println("Using Integer.toString() method to convert college id to string");
		String id=Integer.toString(clgid);
		System.out.println("After conversion the int college Id concat with string \"CSE\" is : "+(id+"AnnaUniversity"));
		System.out.println(" ");
		System.out.println("Using String.format() method to convert rollno to string");
		String deptrollno=String.format("%d",rollno);
		System.out.println("After conversion the rollno concat with string \"CSE\" is : "+("CSE"+deptrollno));
	}

}
