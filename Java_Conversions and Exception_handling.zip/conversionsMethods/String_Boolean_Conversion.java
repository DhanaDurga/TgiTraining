package com.test.conversionsMethods;

import java.util.Scanner;

public class String_Boolean_Conversion 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("enter the two numbers to find which is greater");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		boolean booval;
		String s1 = null,s2=null;
		if(a>b)
		{
			
		 booval= true;	
			System.out.println("a>b is : "+booval);
			System.out.println("Now convert the boolean vlaue true to String :");
			 s1= String.valueOf(booval);
			System.out.println("Using String.valueOf(booval); method to print String: "+s1);
			System.out.println(" ");
			System.out.println("Now again convert the string value to boolean");
			booval=Boolean.parseBoolean(s1);
			System.out.println("Using booval=Boolean.parseBoolean(s1); method to print Boolean: "+booval);
		}
		else
		{
		 booval= false;	
			System.out.println("a>b is : "+booval);
			System.out.println("Now convert the boolean vlaue false to String :");
			 s2= Boolean.toString(booval);
			System.out.println("Using  Boolean.toString(booval); method to print String: "+s2);
			System.out.println(" ");
			System.out.println("Now again convert the string value to boolean");
			booval=Boolean.valueOf(s2);
			System.out.println("Using booval=Boolean.valueOf(s2); method to print Boolean : "+booval);
		}
		System.out.println(" ");
		
		
		

	}

}
