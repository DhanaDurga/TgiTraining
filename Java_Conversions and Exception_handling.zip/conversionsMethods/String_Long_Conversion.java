package com.test.conversionsMethods;

import java.util.Scanner;

public class String_Long_Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long  num,sum;
		String number;
		System.out.println("String-Long Conversion and Vice versa");
		System.out.println(" ");
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a long type Number that can be stored in String object");
		number =sc.next();
		System.out.println("  ");
		System.out.println("Convert the given String value to long value using num =Long.parseLong(number);");
		num =Long.parseLong(number);
		System.out.println("After conversion the value of long is : "+ num);
		sum= num+123445;
		System.out.println("Now this long value is concat with num 123445 ,it will be changed."+sum);
		System.out.println(" ");
		System.out.println(" Long to String Conversion ");
		System.out.println("The answer value(long) is convert to String using number= Long.toString(sum);");
		number= Long.toString(sum);
		System.out.println("AFter conversion the value of String is : "+number);
		System.out.println("");
		System.out.println("The number String value is convert to long using num=Long.valueOf(number);");
		num=Long.valueOf(number);
		System.out.println("After conversion the value of long is : "+ num);
		sum=num+111111;
		System.out.println("Now this long value is concat with num 1111111 ,it will be changed."+sum);
		System.out.println(" ");
		System.out.println(" Long to String Conversion ");
		System.out.println("The answer value(long) is convert to String using number= String.valueOf(sum);");
		number= String.valueOf(sum);
		System.out.println("AFter conversion the value of String is : "+number);
		System.out.println("");
	}

}
