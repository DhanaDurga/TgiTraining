package com.test.conversionsMethods;

import java.util.Scanner;

public class String_Float_Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float  fnum,fsum;
		String fnumber;
		System.out.println("String-Float Conversion and Vice versa");
		System.out.println(" ");
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a Float type Number that can be stored in String object");
		fnumber =sc.next();
		System.out.println("  ");
		System.out.println("Convert the given String value to Float value using fnum =Float.parseFloat(fnumber);");
		fnum =Float.parseFloat(fnumber);
		System.out.println("After conversion the value of Float is : "+ fnum);
		fsum= (float) (fnum+ 45.25);
		System.out.println("Now this Float value is concat with num 45.25 ,it will be changed."+fsum);
		System.out.println(" ");
		System.out.println(" Float to String Conversion ");
		System.out.println("The answer value(Float) is convert to String using fnumber= Float.toString(fsum);");
		fnumber= Float.toString(fsum);
		System.out.println("AFter conversion the value of String is : "+fnumber);
		System.out.println("");
		System.out.println("The number String value is convert to Float using fnum=Float.valueOf(fnumber);");
		fnum=Float.valueOf(fnumber);
		System.out.println("After conversion the value of Float is : "+ fnum);
		fsum=(float) (fnum+110.11);
		System.out.println("Now this Float value is concat with num 110.11 ,it will be changed."+fsum);
		System.out.println(" ");
		System.out.println(" Float to String Conversion ");
		System.out.println("The answer value(Float) is convert to String using fnumber= String.valueOf(fsum);");
		fnumber= String.valueOf(fsum);
		System.out.println("AFter conversion the value of String is : "+fnumber);
		System.out.println("");

	}

}
