package com.test.conversionsMethods;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class String_Date_Conversion 
{
	static void stringtodate()

	{
		System.out.println();
		System.out.println("String to Date Conversion");
		String strdate1="12-05-2022";
		String strdate2="10/30/2022";
		System.out.println("Here SimpleDateFormate class ,only MM -shows the Month of the year and mm -shows the minutes");
		SimpleDateFormat formatter1=new SimpleDateFormat("dd-MM-yyyy"); 
		SimpleDateFormat formatter2=new SimpleDateFormat("MM/dd/yyyy"); 
		try
		{
			Date date1=formatter1.parse(strdate1);
			Date date2=formatter2.parse(strdate2);
			System.out.println("strdate1=\"12-10-2022\"; is convert to Date format => "+ date1);
			System.out.println("strdate2=\"10/30/2022\"; is convert to Date format => "+ date2);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	static void datetostring()
	{
		System.out.println();
		System.out.println(" Date to String Conversion");
		Date date = Calendar.getInstance().getTime();
		System.out.println("Current System time : " + date);
		System.out.println("");
		System.out.println("Current date is convert to given String format");
		SimpleDateFormat formatter = new SimpleDateFormat(" dd-MM-yyyy  HH:mm:ss");
		String str = formatter.format(date);
		System.out.println("Date format with dd-MM-yyyy  HH:mm:ss : " + str);
		System.out.println("");
		formatter = new SimpleDateFormat("dd MMMM yyyy zzzz");
		str = formatter.format(date);
		System.out.println("Date Format with dd MMMM yyyy zzzz 	: " + str);
		System.out.println("");
		formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z");
		str = formatter.format(date);
		System.out.println("Date Format with E, dd MMM yyyy HH:mm:ss z : " + str);
		
		
	}
	public static void main(String[] args)
	
	{
		// TODO Auto-generated method stub
		
		String_Date_Conversion obj=new String_Date_Conversion();
		obj.stringtodate();
		obj.datetostring();
	}

}
