package com.test.conversionsMethods;

import java.util.Scanner;

public class Int_LongDoubleChar_Conversion 
{	
	static int val;
	static void inttolongconvert()
	{
		System.out.println("");
		System.out.println("Int- Long Conversion");
		long l1=val;
		Long l2=new Long(20);
		Long l3=Long.valueOf(val);
		System.out.println("1.long l1=val;  is : "+l1);
		System.out.println("2.Long l2=new Long(20);  is : "+l2);
		System.out.println("3.Long l3=Long.valueOf(val);  is : "+l3);
		
		System.out.println("");
		System.out.println("Long to Int Conversion");
		int i1=(int)l1;
		//long l4=l1+l2;
		int i2=l2.intValue();
		System.out.println("1.int i1=(int)l1; is : "+i1);
		System.out.println("2.int i2=l2.intValue(); is : "+i2);
	}
	static void inttodouble()
	{
		System.out.println("");
		System.out.println("Int-Double Conversion");
		double d1=val;
		Double d2=new Double(12.33);
		Double d3=Double.valueOf(val);
		System.out.println("1.double d1=val;  is : "+d1);
		System.out.println("2.double d2=new Double(12.33);  is : "+d2);
		System.out.println("3.double d3=Double.valueOf(val);  is : "+d3);
		
		System.out.println("");
		System.out.println("double to Int Conversion");
		int i1=(int)d1;
		int i2=d2.intValue();
		System.out.println("1.int i1=(int)d1; is : "+i1);
		System.out.println("2.int i2=d2.intValue(); is : "+i2);
		
	}
	static void inttochar()
	{

		System.out.println("");
		System.out.println("Int-char Conversion");
		char ch=(char) val;
		System.out.println("1.Using char ch=(char) val; ");
		System.out.println("The char value of given integer is : "+ ch);
		System.out.println(" ");
		char intval='9';
		int c=ch;
		int f=Integer.parseInt(String.valueOf(intval));
		System.out.println("Now the char is convert to Integer");
		System.out.println("1. int c=ch => "+c);
		System.out.println("2.Character.getNumericalValue(c); => "+Character.getNumericValue(intval));
		System.out.println("3.Using String.valueOf() => "+f);
		
	}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		System.out.println("Enter a Integer Number For Conversions");
		Scanner sc=new Scanner(System.in);
		val=sc.nextInt();
		inttolongconvert();
		inttodouble();
		inttochar();
	}

}
