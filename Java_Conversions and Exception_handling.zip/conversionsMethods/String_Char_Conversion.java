package com.test.conversionsMethods;

import java.util.Scanner;

public class String_Char_Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char  c,csum;
		String cdata;
		char[] ch;
		System.out.println("String-Character Conversion and Vice versa");
		System.out.println(" ");
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a word that can be stored in String object");
		cdata=sc.next();
		System.out.println("  ");
		System.out.println("Convert the given String value to Character value using charAt();");
		for(int i=0; i<cdata.length();i++)
		{  
	         c = cdata.charAt(i);  
	        System.out.println("char at "+i+" index is: "+c);  
		}
		System.out.println(" ");
		System.out.println(" Character to String Conversion ");
		c=cdata.charAt(0);
		System.out.println("The value(Character index[0]) is convert to String using cdata= Character.toString(c);");
		cdata= Character.toString(c);
		System.out.println("AFter conversion the value of String is : "+cdata);
		cdata=cdata+"Welcome";
		System.out.println("Now the string is concat with \"Welcome\" the value is : "+cdata);
		System.out.println("");
		System.out.println("The  String value is convert to Character using toCharArray() method");
		 ch=cdata.toCharArray();
		for(int i=0;i<ch.length;i++)
		{    
			System.out.println("char at "+i+" index is: "+ch[i]);   
		}  
		System.out.println(" ");
		System.out.println(" Character to String Conversion ");
		System.out.println("The value(Character)  is convert to String using String.valueOf(char Array)");
		for(int i=0;i<ch.length;i++)
		{
		cdata=String.valueOf(ch);
		}
		System.out.println("AFter conversion the value of String is : "+cdata);
		System.out.println("");

	}

}
