package com.test.conversionsMethods;

import java.util.Scanner;

public class String_Double_Conversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double  dnum,dsum;
		String dnumber;
		System.out.println("String-Double Conversion and Vice versa");
		System.out.println(" ");
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a Double type Number that can be stored in String object");
		dnumber =sc.next();
		System.out.println("  ");
		System.out.println("Convert the given String value to Double value using dnum =Double.parseDouble(dnumber);");
		dnum =Double.parseDouble(dnumber);
		System.out.println("After conversion the value of Double is : "+ dnum);
		dsum= dnum+123.556;
		System.out.println("Now this Double value is concat with dnum 123.556 ,it will be changed."+dsum);
		System.out.println(" ");
		System.out.println(" Double to String Conversion ");
		System.out.println("The answer value(Double) is convert to String using dnumber= Double.toString(dsum);");
		dnumber= Double.toString(dsum);
		System.out.println("AFter conversion the value of String is : "+dnumber);
		System.out.println("");
		System.out.println("The number String value is convert to Double using num=Double.valueOf(dnumber);");
		dnum=Double.valueOf(dnumber);
		System.out.println("After conversion the value of Double is : "+ dnum);
		dsum=dnum+111.111;
		System.out.println("Now this Double value is concat with num 111.111 ,it will be changed."+dsum);
		System.out.println(" ");
		System.out.println(" Double to String Conversion ");
		System.out.println("The answer value(Double) is convert to String using dnumber= String.valueOf(dsum);");
		dnumber= String.valueOf(dsum);
		System.out.println("AFter conversion the value of String is : "+dnumber);
		System.out.println("");

	}

}
