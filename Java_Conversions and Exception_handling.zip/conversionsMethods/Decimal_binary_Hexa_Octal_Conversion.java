package com.test.conversionsMethods;

import java.util.Scanner;

public class Decimal_binary_Hexa_Octal_Conversion {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		System.out.println("Given Decimal number convert to Binary,Octal and Hexadecimal:");
		System.out.println("");
		String binarynum=Integer.toBinaryString(num);
		String octnum=Integer.toOctalString(num);
		String hexnum=Integer.toHexString(num);
		System.out.println("Binary number of "+num +"is :"+binarynum);
		System.out.println("Hexadecimal number of "+num +"is :"+hexnum);
		System.out.println("Octal number of "+num +"is :"+octnum);
		System.out.println("");
		System.out.println("Binary to Decimal using Integer.parseInt(binarynum,2); get => "+ Integer.parseInt(binarynum,2));
		System.out.println("HexaDecimal to Decimal using Integer.parseInt(hexnum,2); get => "+ Integer.parseInt(hexnum,16));
		System.out.println("Octal to Decimal using Integer.parseInt(octnum,2); get => "+ Integer.parseInt(octnum,8));
	}

}
