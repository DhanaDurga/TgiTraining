package com.test.collections;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class Vector_Methods {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Vector class implements List and Collection Interface");
		System.out.println(" ");
		try
		{
			Vector<String> vstr=new Vector<String>();
			Vector<String> vint=new Vector<String>(7);
		Vector<Integer> vnew=new Vector<Integer>();
		vstr.add("CSE");
		vstr.addElement("Maths");
		vstr.insertElementAt("Tamil",0);
		vint.add("82");
		vint.add("90");
		vint.add("87");
		vint.elements();
		vnew.addElement(50);
		System.out.println("First Vector List :"+vstr);
		System.out.println("Second Vector List :"+vint);
		vstr.addAll(vint);
		//System.out.println("After All second vector list to First one");
		System.out.println("addAll(); =>First vector list :"+vstr);
		System.out.println("subList() method -Subjects");
		System.out.println(vstr.subList(0, 3));
		System.out.println("Marks");
		System.out.println(vstr.subList(3, 6));
		System.out.println("");
		System.out.println("Accessing elements : ");
		System.out.println("First element of second vector list is : "+vint.firstElement());
		System.out.println("Last element of second vector list is : "+vint.lastElement());
		
		System.out.println(" ");
		System.out.println("First Vector List Hashcode : "+vstr.hashCode());
		System.out.println("Second Vector List Hashcode : "+vint.hashCode());
		System.out.println("vstr.toArray() is : " +vstr.toArray());
		System.out.println("toString()");
		System.out.println(vstr.toString());
		System.out.println(vint.toString());
		System.out.println("");
		System.out.println("First Vector size is : "+vstr.size());
		System.out.println("First Vector List is empty : "+vstr.isEmpty());
		System.out.println(" ");
		System.out.println("The default capacity of Veector List is : "+vstr.capacity());
		System.out.println("Second Vector capacity is : "+vint.capacity());
		//System.out.println(vint.capacity());
		vint.trimToSize();
		System.out.println("After trimToSize(); the Second vector List capacity is : " +vint.capacity());
//		vstr.copyInto(args);
//		System.out.println(args);
		System.out.println("");
		System.out.println("third vector list size is :"+vnew.size());
		vnew.setSize(8);
		System.out.println("After setsize() third vector list size is :"+vnew.size());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
