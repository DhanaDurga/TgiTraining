package com.test.collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedList_Methods_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			LinkedList<String> allink = new LinkedList<String>();
			// System.out.println(allink.size());
			allink.add("Diya");
			allink.add("venu");
			LinkedList<String> al = new LinkedList<String>();
			System.out.println("The size of the linkedlist is : " + al.size());
			al.add("Diya");
			al.add("Maryn");
			al.add(1, "AMmu");
			System.out.println("The elements of Linked List is : "+al);
			System.out.println("After adding The size of the linkedlist is : " + al.size());
			System.out.println("");
			al.addFirst("Dhana");
			al.addLast("Amala");
			System.out.println("After using addFirst() and addLast() methods the LinkedList is : "+al);
			al.addAll(allink);
			System.out.println("");
			// al.add("Ajay",45);
			System.out.println("Using addAll(object);=> append the elements of Specified collection to end of the List ");
			System.out.println(al);
			System.out.println("Now The size of the linkedlist is : " + al.size());
			
			//System.out.println("Its accept the duplicate elements");
			System.out.println(" ");
			System.out.println("Using get() methods");
			//System.out.println("the List : "+al);
			System.out.println("get(1) => "+al.get(1));
			System.out.println("getFirst() => "+al.getFirst());
			System.out.println("getLast() => "+al.getLast());
			System.out.println("getClass() => "+al.getClass());
			System.out.println("element() - returns the first element of the List : "+al.element());
			System.out.println(" ");
			System.out.println("equals() method => "+al.equals(allink));
			System.out.println("containsALl() method => "+al.containsAll(allink));
			
			System.out.println("indexof() and lastIndexOf the given element(Diya) ");
			  System.out.println("index() => " +al.indexOf("Diya"));
			  System.out.println("lastIndexOf() => " +al.lastIndexOf("Diya"));
			
			 
			System.out.println("");
			System.out.println(" Peek(),Poll(),pop(),offer() methods");
			System.out.println(al);
			System.out.println("peek() - retrieve the head of the list => " +al.peek());
			System.out.println("poll() - retrieve and remove the head of the list => "+al.poll());
			System.out.println("now :"+al);
			System.out.println("peekFirst()- retrieve first element => "+al.peekFirst());
			System.out.println("poolLast()- remove last element => "+al.pollLast());
			System.out.println(al);
			System.out.println("");
			System.out.println("offerFirst() = insert the elements => "+al.offerFirst("Sindhu"));
			System.out.println("offerLast() and offer()- insert elements at last => "+al.offerLast("Hema"));
			System.out.println(al);
			System.out.println("pop() same as removeFirst() => "+al.pop());
			System.out.println("now the List is : "+al);
			//System.out.println(" ");
			
			/*
			 * System.out.println("After Iteration -al.iterator()"); Iterator<String> itr =
			 * al.iterator(); while (itr.hasNext()) { System.out.println(itr.next()); }
			 */
			System.out.println("After Iteration - al.descendingIterator();");
			Iterator<String> itr1 = al.descendingIterator();
			while (itr1.hasNext()) {
				System.out.println(itr1.next());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
