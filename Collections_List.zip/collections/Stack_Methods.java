package com.test.collections;

import java.util.Iterator;
import java.util.Stack;

public class Stack_Methods 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Stack class is subclass of vector -LIFO Last In First Out");
		System.out.println("");
		try
		{
		Stack<String> staobj1=new Stack<String>();
		Stack<String> staobj2=new Stack<String>();
		System.out.println("Books List");
		staobj1.add("Computer");
		staobj1.addElement("Database");
		staobj1.add("Python");
		staobj2.add("OOPs");
		staobj2.add(0,"Java");
		staobj2.add("Computer");
		System.out.println("After add elements first Stack list is : "+staobj1);
		System.out.println("After add elements Second Stack list is : "+staobj2);
		System.out.println("");
		System.out.println("The First stack default capacity is : " +staobj1.capacity());
		System.out.println("The First stack List size is : " +staobj1.size());
		System.out.println("The Second stack list is empty : "+staobj2.empty());
		System.out.println("The Second stack default capacity is : " +staobj2.capacity());
		staobj2.ensureCapacity(12);
		System.out.println("The Second stack  ensureCapacity(12) is -double the old capacity : " +staobj2.capacity());
		System.out.println("");
		System.out.println("Accessing elements inth stack list");
		System.out.println("First stack contains \"java\" is : "+staobj1.contains("Java"));
		System.out.println("elementAt(1)-retuens the Second stack element of the given index :"+ staobj2.elementAt(1));
		System.out.println("equals() method -comparision : " +staobj1.equals(staobj2));
		//System.out.println(staobj1.elements());
		System.out.println("");
		System.out.println("The First stack first elements is : "+staobj1.firstElement());
		System.out.println("The Second stack last elements is : "+staobj2.lastElement());
		System.out.println("Index of \"Database\" is : " +staobj1.indexOf("Database"));
		System.out.println(" ");
		System.out.println("After push() method First stack List is : "+staobj1.push("Graphics"));
		System.out.println(staobj1);
		staobj1.removeElementAt(1);
		System.out.println("After removeElementAt(1); => "+staobj1);
		System.out.println("");
		System.out.println("Stack representation:");
		System.out.println("search() method -to return the position of the element in stack List");
		System.out.println("staobj1.search(\"computer\") => " +staobj1.search("Computer"));
		System.out.println("staobj1.search(\"Python\") => " +staobj1.search("Python"));
		System.out.println("staobj1.search(\"Graphics\") => " +staobj1.search("Graphics"));
	System.out.println("");
		System.out.println("After Iteration");
	Iterator itr= staobj1.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
		}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}

}
}
