package com.test.collections;

import java.util.ArrayList;

public class ArrayList_Methods 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try
		{
		System.out.println("Array List Methods");
		ArrayList<Integer> alint=new ArrayList<Integer>();
		ArrayList<Integer> alint1=new ArrayList<Integer>(10);
		ArrayList<Integer> alint2=new ArrayList<Integer>();
		System.out.println("boolean add()");
		alint.add(5);
		alint.add(20);
		System.out.println("First ArrayList : "+alint);
		alint1.add(0,40);
		System.out.println("Second ArrayList : "+alint1);
		System.out.println("");
		System.out.println("boolean addAll(collection)");
		alint.addAll(alint1);
		System.out.println("Now First ArrayList is : "+alint);
		System.out.println("get(1); => "+alint.get(1));
		alint.set(1, 32);
		System.out.println("set(1,32); now, the First ArrayList is : => "+alint);
		System.out.println("");
		System.out.println("The Second arrayList all elements removeAll() from First ArrayList");
		alint.removeAll(alint1);
		System.out.println(alint);
		System.out.println("Clear() Method");
		alint1.clear();
		System.out.println("Now, the second Array elements are ; "+alint1);
		System.out.println(" ");
		System.out.println("Size() and isEmpty() methods");
		System.out.println("First ArrayList size is : "+alint.size());
		System.out.println("Second ArrayList is empty : "+alint1.isEmpty());
		System.out.println("Check the First ArrayList \"contains\" Second ArrayList elements : " +alint.contains(alint1));
		System.out.println("");
		
		/*
		 * alint1.ensureCapacity(3);
		 * System.out.println("ensure capacity od third ArrayLiat is : "+
		 * alint1.size());
		 */
				  
		  alint2.add(0,11);
		  alint2.add(1,52);
		  alint.add(88);
		  System.out.println("The third ArrayList elements are : "+alint2);
		  System.out.println("The First ArrayList elements are : "+alint);
		  System.out.println("The Second ArrayList elements are : "+alint1);
		  System.out.println("First ArrayList lastIndexOf(88) => "+alint.lastIndexOf(88));
		  System.out.println("Second ArrayList lastIndexOf(88) if return -1 not available => "+alint1.lastIndexOf(88));
		 
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
