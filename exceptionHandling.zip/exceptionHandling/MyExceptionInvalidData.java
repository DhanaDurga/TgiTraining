package com.test.exceptionHandling;

public class MyExceptionInvalidData extends Exception {

	public MyExceptionInvalidData(String message) {
		
		super(message);
		// TODO Auto-generated constructor stub
	}

}
