package com.test.exceptionHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import com.test.exceptionHandling.MyException;
import com.test.exceptionHandling.MyExceptionInvalidData;

public class ExceptionHandlingExample {
	public static void withoutException() {
		System.out.println("\n" + "Without Exception -rest of the code doesn't executed");
		int[] a = new int[5];
		a[7] = 30;
		System.out.println("ArrayIndexOutOfBoundsException");
	}

	public static void arithmatic() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Perform Arithmatic Exception");
		System.out.println("Enter two numbers to perform Division operation");
		int number = sc.nextInt();
		int divisor = sc.nextInt();
		try {
			int ans = number / divisor;
			System.out.println("The answer is : " + ans);
		} catch (ArithmeticException e) {
			System.out.println(e);
			System.out.println("Number not divided by 0");
		}
	}

	public static void nullNumber() {
		String two = null;
		try {System.out.println("\n" + " Find the length of the null value");
			System.out.println("nullString.length = " + two.length());
		} catch (NullPointerException e) {
			System.out.println(e);
			System.out.println(
					"If we have a null value in any variable, performing any operation on the variable throws a NullPointerException.");
		}
	}

	public static void nestedtry(String one) {
		try {

			int i = Integer.parseInt(one);
			System.out.println("\n" + "Character/null String to int : " + i);
		} catch (ArithmeticException e) {
			System.out.println(e);

		}
	}

	public static void numberFormat() {
		Scanner sc = new Scanner(System.in);
		System.out.println("\n" + "Enter a string : ");
		String one = sc.next();
		try {System.out.println("String.length = " + one.length());
			System.out.println("Nested try block" );
			nestedtry(one);
		} catch (NumberFormatException | NullPointerException e) {
			System.out.println(e);
		} finally {
			System.out.println(
					"If you don't have numbers in string literal, calling Integer.parseInt() or Integer.valueOf() methods throw NumberFormatException.");

		}
	}

	public static void arrayIndex() {
		try {
			System.out.println("\n" + "Array size is : int a[]=new int[5]; If assign value in a[7]=30; means ");
			int[] a = new int[5];
			a[7] = 30; // ArrayIndexOutOfBoundsException
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
			System.out.println("When an array exceeds to it's size, the ArrayIndexOutOfBoundsException occurs. ");
		}
	}
	public static void stringIndex()
	{
		try
		{String str="Happy New Year 2023";
		System.out.println("\n"+"length of String is = \"Happy New Year 2023\"; => "+str.length());
		System.out.println("Find the 30th character in the string: ");
		System.out.print(str.charAt(30));
		}catch(StringIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
	}
	public static void fileFound()
	{
		try {
		File filepath=new File("");
		FileReader fr=new FileReader(filepath);}
		catch(FileNotFoundException e){
			System.out.println("\n"+"File doesn't exist in the given path following exception occurs");
			System.out.println(e);
		}
		
	}
	public static void classCheck() {
		try {
			Class.forName("check");}
		catch(ClassNotFoundException e) {
			System.out.println("\n"+"Class doesn't exist in the given path following exception occurs");
			System.out.println(e);}
	}

	public static void main(String[] args) {
		try {

			arithmatic();
			nullNumber();
			numberFormat();
			stringIndex();
			arrayIndex();
			fileFound();
			classCheck();
			try{
				
				System.out.println("\n"+"Custom Exception or User defined Exception");
				check obj=new check();
				obj.vote(16);
				
			}
			catch (MyExceptionInvalidData exe) 
			{System.out.println("Using \"throw\" handle the Exception"+"\n"+"Using \"throws\" declare the Exception in method signature");
			System.out.println("The user defined Exception is : "+exe.getMessage());
			}
			catch(MyException ex)
			{
				System.out.println("Handled empty Exception");
				System.out.println("The Exception is : "+ex.getMessage());
			}
			check obj=new check();
			obj.call();
			
			//withoutException();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
	
			System.out.println("\n"+"Finally block -Using Exception Handling the rest of the code is executed");
		}
	}

}
class check
{
	public void vote(int age) throws MyExceptionInvalidData,MyException
	{
		
		System.out.println("Check age=16 eligible for voting ");
		if(age<18) {
			 throw new MyExceptionInvalidData("MyExceptionInvalidData - Not Eligible for voting");
		}else throw new MyException(); 
		
	}
	public void call()
	{	System.out.println("\n" + "Without Exception -rest of the code doesn't executed");
			check parent=new child();//upcasting
			parent.classcast();
			check parentobj=new check();
			child childobj=(child)parentobj;//downcasting
		
		
		
	}
	public void classcast()
	{
		System.out.println(" Parent calss method");
	}
}
class child extends check
{public void classcast()
{
	System.out.println("upcasting -Child calss method");
}
	
}
