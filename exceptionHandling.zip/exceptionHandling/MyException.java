package com.test.exceptionHandling;

public class MyException extends Exception {

}
