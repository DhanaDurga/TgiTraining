package ExcelTODatabaseEmployeeDetails;
import java.io.*;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelToDatabase {
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String JDBC_URL = "jdbc:mysql://localhost:3306/training";
	static final String USER_NAME = "root";
	static final String PASSWORD = "root";

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub

		FileInputStream fis = null;
		ArrayList dbdata = new ArrayList();
		try {
			File file = new File("D:\\Dhana\\employee.xlsx");
			fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rowitr = sheet.rowIterator();
			
			System.out.println("Read the Excel document datas :");
			System.out.println("");
			while (rowitr.hasNext())

			{

				XSSFRow row = (XSSFRow) rowitr.next();
				Iterator<Cell> cellitr = row.cellIterator();
				while (cellitr.hasNext()) {
					XSSFCell cell = (XSSFCell) cellitr.next();

					System.out.print(cell.toString() + "  ");
				}
				System.out.println("");

			}

			List<employeeModel> list = new ArrayList<employeeModel>();
			XSSFRow row;
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i);

				long employeeId;
				if (row.getCell(0) == null) {
					employeeId = 0;
				} else
					employeeId = Long.parseLong(row.getCell(0).getRawValue());

				String firstName;
				if (row.getCell(1) == null) {
					firstName = "null";
				} else
					firstName = row.getCell(1).toString();

				String middleName;
				if (row.getCell(2) == null) {
					middleName = "null";
				} else
					middleName = row.getCell(2).toString();

				String lastName;
				if (row.getCell(3) == null) {
					lastName = "null";
				} else
					lastName = row.getCell(3).toString();

				String fullName;
				if (row.getCell(4) == null) {
					fullName = "null";
				} else
					fullName = row.getCell(4).toString();

				String emailId;
				if (row.getCell(5) == null) {
					emailId = "null";
				} else
					emailId = row.getCell(5).toString();

				String education;
				if (row.getCell(6) == null) {
					education = "null";
				} else
					education = row.getCell(6).toString();

				long phno;
				if (row.getCell(7) == null) {
					phno = 0;
				} else
					phno = Long.parseLong(row.getCell(7).toString());

				String dob;
				SimpleDateFormat formatter = new SimpleDateFormat(" dd-MM-yyyy ");
				
				if (row.getCell(8) == null) {
					dob = null;
				} else
					//dob = (Date) (row.getCell(8).getDateCellValue());
				dob = formatter.format(row.getCell(8).getDateCellValue()) ;
				 

				
				String gender;
				if (row.getCell(9) == null) {
					gender = "null";
				} else
					gender = row.getCell(9).toString();

				String add1;
				if (row.getCell(10) == null) {
					add1 = "null";
				} else
					add1 = row.getCell(10).toString();

				String add2;
				if (row.getCell(11) == null) {
					add2 = "null";
				} else
					add2 = row.getCell(11).toString();

				long pin;
				if (row.getCell(12) == null) {
					pin = 0;
				} else
					pin = Long.parseLong(row.getCell(12).toString());

				String city;
				if (row.getCell(13) == null) {
					city = "null";
				} else
					city = row.getCell(13).toString();

				String state;
				if (row.getCell(14) == null) {
					state = "null";
				} else
					state = row.getCell(14).toString();

				String jobDesignation;
				if (row.getCell(15) == null) {
					jobDesignation = "null";
				} else
					jobDesignation = row.getCell(15).toString();

				String jobRole;
				if (row.getCell(16) == null) {
					jobRole = "null";
				} else
					jobRole = row.getCell(16).toString();

				String jd = row.getCell(17).toString();

				long sal;
				if (row.getCell(18) == null) {
					sal = 0;
				} else
					sal = (long) (Double.parseDouble(row.getCell(18).toString()));

				double perAnnum;
				if (row.getCell(19) == null) {
					perAnnum = 0;
				} else
					perAnnum = Double.parseDouble(row.getCell(19).toString()) / 100000.0;

				UUID id = UUID.randomUUID();
				String uuid = id.toString();
				
		// create POJO file for get and set data
				employeeModel emp = new employeeModel();
				emp.setId(uuid);
				emp.setempId(employeeId);
				emp.setFirstName(firstName);
				emp.setMiddleName(middleName);
				emp.setLastName(lastName);
				emp.setFullName(fullName);
				emp.setMailId(emailId);
				emp.setEducation(education);
				emp.setPhno(phno);
				emp.setDob(dob);
				emp.setGender(gender);
				emp.setAdd1(add1);
				emp.setAdd2(add2);
				emp.setPin(pin);
				emp.setCity(city);
				emp.setState(state);
				emp.setJobDesignation(jobDesignation);
				emp.setJobRole(jobRole);
				emp.setJd(jd);
				emp.setSal(sal);
				emp.setPerAnnum(perAnnum);

				list.add(emp);
			}
			call(list);//insert values to the database
			String highSalEmp = read();//perform update and retrieve process
			delete(highSalEmp);//delete a record from table

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
		}

	}

	static void call(List<employeeModel> empList) {

		try {
			
			System.out.println("");
			System.out.println("Datas loading to database......");
			Class.forName(JDBC_DRIVER);

			Connection conn = DriverManager.getConnection(JDBC_URL, USER_NAME, PASSWORD);

			for (employeeModel emp : empList) {

				String sql = "insert into example values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement smt = conn.prepareStatement(sql);

				smt.setString(1, emp.getId());
				smt.setLong(2, emp.getempId());
				smt.setString(3, emp.getFirstName());
				smt.setString(4, emp.getMiddleName());
				smt.setString(5, emp.getLastName());
				smt.setString(6, emp.getFullName());
				smt.setString(7, emp.getMailId());
				smt.setString(8, emp.getEducation());

				smt.setLong(9, emp.getPhno());
				smt.setString(10, emp.getDob());
				smt.setString(11, emp.getGender());
				smt.setString(12, emp.getAdd1());
				smt.setString(13, emp.getAdd2());
				smt.setLong(14, emp.getPin());
				smt.setString(15, emp.getCity());
				smt.setString(16, emp.getState());
				smt.setString(17, emp.getJobDesignation());
				smt.setString(18, emp.getJobRole());
				smt.setString(19, emp.getJd());
				smt.setLong(20, emp.getSal());
				smt.setDouble(21, emp.getPerAnnum());
				smt.executeUpdate();

			}
			System.out.println("");
			System.out.println("Now process completed...Data inserted to database");
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	static String read() throws ClassNotFoundException {
		String higherSalary = null;
		try {
			int a;

			Class.forName(JDBC_DRIVER);

			Connection conn = DriverManager.getConnection(JDBC_URL, USER_NAME, PASSWORD);

			PreparedStatement smt = conn.prepareStatement("update example set city=? , add2=? where empId=?");

			smt.setString(1, "Tirunelveli");
			smt.setString(2, "Tirunelveli");
			smt.setInt(3, 128);

			a = smt.executeUpdate();
			System.out.println("");
			System.out.println(
					"Update the some fields  value of the table - update example set city=Tirunelveli, add2=Tirunelveli where empId=128");

			System.out.println(a + "  record updated into table example");

			System.out.println("");
			System.out.println("Retrieve the data whose salary are >=50000");
			ResultSet rs = smt.executeQuery("select empId,fullname,sal from example where sal>=50000");
			while (rs.next()) {
				System.out.println(rs.getString("empId") + " " + rs.getString("fullname") + " " + rs.getInt("sal"));
				higherSalary = rs.getString("empId");
			}
			System.out.println("");

			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return higherSalary;
	}

	private static void delete(String highSalEmp) throws ClassNotFoundException {
		try {

			if (null != highSalEmp)
				Class.forName(JDBC_DRIVER);

			Connection conn = DriverManager.getConnection(JDBC_URL, USER_NAME, PASSWORD);

			PreparedStatement smt = conn.prepareStatement("delete from example where empId=?");
			smt.setString(1, highSalEmp);
			int a = smt.executeUpdate();
			System.out.println("Delete high salary person data from database Table");
			System.out.println(a + "  record deleted from table example");
			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
