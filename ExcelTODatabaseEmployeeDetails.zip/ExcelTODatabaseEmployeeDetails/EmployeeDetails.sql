SELECT * FROM training.example;

describe training.example;

truncate training.example;

drop table training.example;

create table training.example(id varchar(255) not null,empId varchar(20) not null, first_name varchar(20) not null,middle_name varchar(20),last_name varchar(20) not null,fullName varchar(20),mailId varchar(40),
education varchar(20),phone BIGINT(255), dob varchar(40),gender varchar(20),add1 varchar(100),add2 varchar(100),pin int,city varchar(20),state varchar(20),jobDesignation varchar(20),
jobRole varchar(20),jd varchar(30),sal int,perAnnum_LPA  decimal(10,2) , primary key (id,empId));


