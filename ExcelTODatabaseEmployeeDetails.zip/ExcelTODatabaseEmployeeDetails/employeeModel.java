package ExcelTODatabaseEmployeeDetails;
import java.util.Date;

public class employeeModel {
	
	
	private String id;
	private long empId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String fullName;
	private String  mailId;
	private String education;
	private long phno;
	
	private String dob;
	private  String gender;
	private String add1;
	private String add2;
	private long pin;
	private String city;
	private String state;
	private String jobDesignation;
	private String jobRole;
	private String jd;
	private long sal;
	private Double perAnnum;
	
	public employeeModel() {
		
	}
	
	public employeeModel(String id,long empId, String firstName, String middleName, String lastName, String fullName, String mailId,
			String education, long phno,String dob, String gender, String add1, String add2, long pin, String city, String state,
			String jobDesignation, String jobRole, String jd, long sal, Double perAnnum) {
		super();
		this.id=id;
		this.empId = empId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.fullName = fullName;
		this.mailId = mailId;
		this.education = education;
		this.phno=phno;
		this.dob = dob;
		this.gender = gender;
		this.add1 = add1;
		this.add2 = add2;
		this.pin = pin;
		this.city = city;
		this.state = state;
		this.jobDesignation = jobDesignation;
		this.jobRole = jobRole;
		this.jd = jd;
		this.sal = sal;
		this.perAnnum = perAnnum;
	}

	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public long getempId() {
		return empId;
	}

	public void setempId(long empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}
	public long getPhno() {
		return phno;
	}

	public void setPhno(long phno) {
		this.phno = phno;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAdd1() {
		return add1;
	}

	public void setAdd1(String add1) {
		this.add1 = add1;
	}

	public String getAdd2() {
		return add2;
	}

	public void setAdd2(String add2) {
		this.add2 = add2;
	}

	public long getPin() {
		return pin;
	}

	public void setPin(long pin) {
		this.pin = pin;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getJobDesignation() {
		return jobDesignation;
	}

	public void setJobDesignation(String jobDesignation) {
		this.jobDesignation = jobDesignation;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public String getJd() {
		return jd;
	}

	public void setJd(String jd) {
		this.jd = jd;
	}

	public long getSal() {
		return sal;
	}

	public void setSal(long sal) {
		this.sal = sal;
	}

	public Double getPerAnnum() {
		return perAnnum;
	}

	public void setPerAnnum(Double perAnnum) {
		this.perAnnum = perAnnum;
	}

	

}
	
	
