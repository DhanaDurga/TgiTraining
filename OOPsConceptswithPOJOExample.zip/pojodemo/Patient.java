package com.test.pojodemo;

public class Patient 
{
	private String name;
	private int regno;
	private String disease;
	private char bloodgroup;
	private double fee;
	private String doctor;
	private String hospital;
	private char rhfactor;

	public char getRhfactor() {
		return rhfactor;
	}

	public void setRhfactor(char rhfactor) {
		this.rhfactor = rhfactor;
	}

	public String getHospital() {
		return hospital;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRegno() {
		return regno;
	}

	public void setRegno(int regno) {
		this.regno = regno;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public char getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(char bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

}
