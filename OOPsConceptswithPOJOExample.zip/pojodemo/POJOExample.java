package com.test.pojodemo;

public class POJOExample 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Patient obj=new Patient();
		obj.setName("Perumal");
		obj.setRegno(4562);
		obj.setBloodgroup('A');
		obj.setRhfactor('-');
		obj.setDisease("Diabetic");
		obj.setFee(6000);
		obj.setDoctor("Dr.Manikandan ");
		obj.setHospital("Mani's Diabetes care");
		System.out.println("Hospital Name : "+obj.getHospital());
		System.out.println(" ");
		System.out.println("Patient Name is : "+ obj.getName());
		System.out.println("Registration Number : "+obj.getRegno());
		System.out.println("Blood group : "+obj.getBloodgroup()+obj.getRhfactor());
		System.out.println("Patient Health issue :"+obj.getDisease());
		System.out.println("Total fees :"+obj.getFee());

	}

}
