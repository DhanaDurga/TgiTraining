package com.test.OOPsConcepts;

import java.util.Scanner;
interface Balance 	// Interface declaration
{
	void withdraw(int n);
}

abstract class Option implements Balance //Abstract Class implements interface
{
	// Abstract class have abstract and non-abstract methods
	
	abstract void credit();
	
	public void withdraw(int n)	//Abstract class can provide the implementation of interface.
	{
		
		System.out.println("Amount withdraw from Account balance : "+n);
		
	}
}

class calculate extends Option  //Inheritance - acquires all the properties and behaviors of a parent object.
{
	double amount=15000.45;
	public void interest()
	{
		System.out.println(" ");
		System.out.println("Create Object for a Class calculate and calling a method interest to execute following:");
		System.out.println("Monthly Bank Interest : 125.00");
		this.amount=amount+125;
		System.out.println("Account Balance after the consolidated interest including : "+amount);
		
	}
	public void credit()
	
	{
		System.out.println(" ");
		System.out.println("Calling credit overloading method within a class -non-parameterized ");
		System.out.println("Every Monthly salary Rs 10000 is credited in your Account");
		this.amount=amount+ 10000;
		System.out.println("Updated Account Balance after Credit : "+amount);
		
	}
	public void credit(int n) //Polymorphism -Method OverLoading
	{
		System.out.println(" ");
		System.out.println("Calling credit overloading method within a class -parameterized ");
		System.out.println("Amount Rs "+ n +" credited in your Account");
		this.amount = amount + n;
		System.out.println("Account Balance after Credit : " + amount);
	
	}
	public void withdraw(int n)	//Polymorphism - Method Overriding
	{
		System.out.println(" ");
		System.out.println("Calling withdraw overriding method from parent class");
		System.out.println("Amount withdraw from Account balance : "+n);
		this.amount=amount-n;
		System.out.println("Available Account balance after withdraw Rs "+n +" :"+amount);
	}
	
}
public class OOPsConceptExample
{
 
	public static void main(String[] args) {
		System.out.println("Executing the program using OOPs Concepts -Class ,Object ,Inheritamce , Polymorphism ,Encapsulation and Abstraction");
		System.out.println(" ");
		String myname="Dhana.M";
		try
		{
			
		System.out.println("Enter Your Name that present in ID Proof: ");
		Scanner sc=new Scanner(System.in); 	//Get the input from user
		String name= sc.next();
		String msg= "Invalid Person";
		//String person=(name== myname )? myname: msg;
		boolean a =(name.equals(myname));
			if(a)
			{
			//Binding (or wrapping) code and data together into a single unit are known as encapsulation
			
				AccountDetails obj=new AccountDetails(); //Encapsulate Account Details - access using get and set methods
				obj.setAccholder(name);
				obj.setAccno(310024510);
				obj.setBankname("Canara Bank");
				obj.setEmail("dhana@gmail.com");
				obj.setAccbalance(15000.45);
				System.out.println(" ");
				System.out.println("Encapsulate Account Details - access using get and set methods");
				System.out.println("Account Details");
				System.out.println(" ");
				System.out.println("Account Holder Name : "+obj.getAccholder());
				System.out.println("Bank Name : "+obj.getBankname());
				System.out.println("Account Number : "+obj.getAccno());
				System.out.println("Account Holder Mail-Id: "+obj.getEmail());
				System.out.println("Current Account Balance : "+obj.getAccbalance());
				System.out.println(" ");
				calculate calobj=new calculate(); //Create Object for a Class calculate
				calobj.interest();
				calobj.credit();
				calobj.credit(5000);
				Balance calobj1=new calculate();
				//calobj1.withdraw(500);
				calobj.withdraw(500);
					
		}
		else
			System.out.println(msg);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
