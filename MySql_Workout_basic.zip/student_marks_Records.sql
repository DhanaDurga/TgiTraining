/*
-- Query: select * from student_marks
LIMIT 0, 1000

-- Date: 2022-11-25 13:48
*/
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (101,'Dhana',90.5,'Pass');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (102,'Mala',85.7,'Pass');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (103,'Mala',60.2,'Fail');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (104,'Venu',75.2,'pass');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (105,'Dhanam',90.5,'Pass');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (106,'Malar',63.2,'Fail');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (108,'Riya',75.2,'pass');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (109,'Selva',55.5,'Fail');
INSERT INTO `` (`student_rollno`,`first_name`,`percentage`,`result`) VALUES (110,'Reena',75.2,'pass');
