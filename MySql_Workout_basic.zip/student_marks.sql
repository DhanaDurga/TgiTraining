create table student_marks(student_rollno int not null auto_increment, first_name varchar(20) not null, 
percentage float not null,result varchar(10) not null, primary key (student_rollno));

insert into student_marks(percentage,result)value('90.0','Pass');

insert into student_marks(student_rollno,first_name) select student_rollno,first_name from student_details;

alter table student_marks drop column percentage;

 alter table student_marks drop column result;
 
 select * from student_marks;
 
 insert into student_marks(student_rollno,first_name) select student_rollno,first_name from student_details;
 
 alter table student_marks add column (percentage float not null, result varchar(10) not null);
 
 update training.student_marks set percentage='90.5',result='Pass' where student_rollno in ('101','105','107');
 
update training.student_marks set percentage='85.7',result='Pass' where student_rollno in ('102');
  
update training.student_marks set percentage='60.2',result='Fail' where student_rollno in ('103');
   
update training.student_marks set percentage='63.2',result='Fail' where student_rollno in ('106');
    
update training.student_marks set percentage='55.5',result='Fail' where student_rollno in ('109');
     
update training.student_marks set percentage='75.2',result='pass' where student_rollno in ('104','110','108');

select min(percentage) as Minimum_Percentage_Marks from student_marks;

select  max(percentage) as Topper from student_marks;

select count(result) as GradeStudents from student_marks where result='Pass';

select count(result)  from student_marks where result='Fail';



   