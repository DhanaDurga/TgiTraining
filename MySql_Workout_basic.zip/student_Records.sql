/*
-- Query: select * from training.student_details
LIMIT 0, 1000

-- Date: 2022-11-25 11:34
*/
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (101,'Dhana','M','CSE','Anna Univ','chennai','2015-10-24','2019-05-20','abc2gmail.com',789153145);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (102,'Mala','M','CSE','Kamaraj','chennai','2015-10-24','2019-05-20','mala@gmail.com',974531256);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (103,'Mala','S','CSE','Anna Univ','Madurai','2015-10-24','2019-05-20','malas@gmail.com',974531256);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (104,'Venu','R','IT','Anna Univ','chennai','2015-10-24','2019-05-20','venu@gmail.com',974512256);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (105,'Dhanam','M','IT','Kamaraj','Madurai','2015-10-24','2019-05-20','dhana@gmail.com',971431256);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (106,'Malar','S','CSE','Anna Univ','chennai','2015-10-24','2019-05-20','malar@gmail.com',974531256);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (107,'Amala','N','CSE','Anna Univ','Madurai','2015-10-24','2019-05-20','amala@gmail.com',974331256);
INSERT INTO `` (`student_rollno`,`first_name`,`last_name`,`department`,`college_name`,`city`,`course_joining`,`passed_out`,`mail_id`,`phone_no`) VALUES (108,'Riya','S','IT','Anna Univ','chennai','2015-10-24','2019-05-20','riya@gmail.com',974531256);
