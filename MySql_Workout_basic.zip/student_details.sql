use training;
create table student_details(student_rollno int not null auto_increment, first_name varchar(20) not null,last_name varchar(20) not null,
department varchar(5) not null,college_name varchar(10) not null,city varchar(10) not null, course_joining date, passed_out date,
mail_id varchar(15) not null, phone_no int(10) , primary key ( student_rollno));

insert into training.student_details(student_rollno,first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('101','Dhana','M','CSE','Anna Univ','chennai','20151024','20190520','abc2gmail.com','789153145');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Mala','M','CSE','Anna Univ','chennai','20151024','20190520','mala@gmail.com','974531256');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Mala','S','IT','Anna Univ','chennai','20151024','20190520','malas@gmail.com','884531256');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Dhanam','M','IT','Anna Univ','chennai','20151024','20190520','dhana@gmail.com','971431256');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Malar','S','CSE','Anna Univ','chennai','20151024','20190520','malar@gmail.com','974531256');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Amala','N','CSE','Anna Univ','chennai','20151024','20190520','amala@gmail.com','974331256');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Riya','S','IT','Anna Univ','chennai','20151024','20190520','riya@gmail.com','974531256');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id,phone_no) values ('Venu','R','IT','Anna Univ','chennai','20151024','20190520','venu@gmail.com','974512256');

select * from training.student_details;

select * from training.student_details where (department='CSE');

select department,student_rollno,first_name from training.student_details where(department='IT');

select first_name,last_name,mail_id from training.student_details order by first_name asc;

select first_name,last_name,mail_id from training.student_details order by first_name desc;

update training.student_details set city='Madurai' where student_rollno in ('10','105','107');

select * from training.student_details;

update training.student_details set college_name='Kamaraj University' where first_name='Dhanam';

alter table training.student_details modify college_name varchar(20);

update training.student_details set college_name='Kamaraj University' where first_name='Dhanam';

update training.student_details set college_name='Anna University' where college_name='Anna Univ';

update training.student_details set college_name='Kamaraj University ' where first_name='Mala' and last_name='M';

select * from training.student_details where not department='CSE';

select first_name from training.student_details where phone_no is not null;

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id) values ('Reena','B','CSE','IIT','chennai','20151020','20190520','reena@gmail.com');

insert into training.student_details(first_name,last_name,department,college_name,city,course_joining,passed_out,
mail_id) values ('Selva','S','CSE','IIT','chennai','20151020','20190520','selva@gmail.com');

select first_name from training.student_details where phone_no is null;

delete from training.student_details where first_name='Amala';

select * from training.student_Details;













