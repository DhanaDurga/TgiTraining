package javaDatatypes;

/*
int intVar;
Size: 4 byte ( 32 bits )

Values: -2, 147, 483, 648 to 2, 147, 483, 647 (inclusive)

Note: The default value is ‘0’
*/
public class Intdata {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		//int data types variables
		int m1=80;
		int m2=70;
		int m3=90;
		int handwriting =10;
		int total= m1+m2+m3-handwriting;
		System.out.println("Student mark details:");
		System.out.println("M1 value:"+m1);
		System.out.println("M2 value:"+m2);
		System.out.println("M3 value:"+m3);
		System.out.println("Handwriting marks:-"+handwriting);
		System.out.println("Total marks :"+ total);
		
	}

}
