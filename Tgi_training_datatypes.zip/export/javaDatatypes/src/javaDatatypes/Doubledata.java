package javaDatatypes;

/*Syntax:

double doubleVar;
Size: 8 bytes or 64 bits

Values: Upto 16 decimal digits

Note: 

The default value is taken as ‘0.0’.
*/
public class Doubledata 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Doubledata dubData = new Doubledata();
		double cost[] = {22.55,34.07,17.29,54.13,49.21};
		System.out.println("The double data type cost values are:");
		System.out.println("The total cost is: "+dubData.getTotalCost(cost));
	}

	private double getTotalCost(double[] cost) 
	{
		// TODO Auto-generated method stub
		double totalcost =0.00;
		for(Double eachCost : cost) {
			System.out.println(eachCost);
			totalcost = totalcost + eachCost;
		}
		return totalcost;
	}

}
