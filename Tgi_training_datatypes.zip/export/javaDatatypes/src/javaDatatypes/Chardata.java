package javaDatatypes;


/*Syntax: 

char charVar;
Size: 2 byte (16 bits)

Values: ‘\u0000’ (0) to ‘\uffff’ (65535)

Note: The default value is ‘\u0000’
*/


public class Chardata {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int totalMark = 500; 
		//Chardata data=new Chardata();
		gradeEvaluator(totalMark);
	}

	
	public static void gradeEvaluator(int total) 
	{
		char grade1= 'A';
		System.out.println("Student grade details using char data type:\n");
		if(total>550)
			System.out.println("Student total marks greater than 550 so grade is: "+grade1);
		else if(total>450)
		{
		grade1++;
		
		System.out.println("Student total marks greater than 450 so grade is: "+grade1);
	
		}
		else
		{
		grade1++;
		System.out.println("Student total marks less than 450 so grade is: "+grade1);
		}
	 }

}
