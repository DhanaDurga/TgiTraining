package javaDatatypes;

/*Syntax: 

long longVar;
Size: 8 byte (64 bits)

Values: {-9, 223, 372, 036, 854, 775, 808} to {9, 223, 372, 036, 854, 775, 807} (inclusive)

Note: The default value is ‘0’.
*/
public class Longdata 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		long num1= 4500000L;
		long num2= 6500000L;
		System.out.println("Addition of two long values:\n"+num1);
		System.out.println(num2);
		long result= num1+num2;
		System.out.println("The result is:"+result);
	}

}
