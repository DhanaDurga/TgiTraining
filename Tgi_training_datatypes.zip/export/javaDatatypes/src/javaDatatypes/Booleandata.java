package javaDatatypes;
import java.util.Scanner;

public class Booleandata {

	/*
	 * The boolean data type has two possible values, either true or false. Default
	 * value: false.
	 */
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		
		//boolean data types variables -either true or false
		boolean eligible=false;
		
		
		System.out.println("Enter your age:");
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		if(age>18)
		{ eligible=true;
		
		}
		if(eligible)
			System.out.println("you are Eligible to vote");
		else
			System.out.println("you are not Eligible to vote ");
	}

}
