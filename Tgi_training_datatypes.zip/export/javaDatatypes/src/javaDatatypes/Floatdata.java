package javaDatatypes;
import java.util.Scanner;

/*Syntax: 

float floatVar;
Size: 4 byte (32 bits)

Values: upto 7 decimal digits

Note: The default value is ‘0.0’.
*/
public class Floatdata 
{
	static void div(float x,float y)
	
	{
		float result= x/y;
		System.out.println("The reult is:"+result);
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two int/float numbbers for division :");
		float no1=sc.nextFloat();
		float no2=sc.nextFloat();
		div(no1,no2);
	}

}
