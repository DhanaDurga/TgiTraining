package javaDatatypes;

public class Asciivalue 
{

	public static void main(String[] args) 
	{
		/*
		 * // TODO Auto-generated method stub char[] val= {'A','B','Z','a','b','z'};
		 * System.out.println("ASCII values of alphabets:");
		 *  for(int value:val) 
		 *  {
		 * System.out.println(value); 
		 * }
		 */
		
		char ch1 = 'A';  
		char ch2 = 'Z';  
		char ch3 = 'a';  
		char ch4 = 'z';  
		// variable that stores the integer value of the character  
		int asciivalue1 = ch1;  
		int asciivalue2 = ch2;
		int asciivalue3= ch3;  
		int asciivalue4 = ch4;  
		System.out.println("ASCII values of alphabets:\n");
		System.out.println("The ASCII value of " + ch1 + " is: " + asciivalue1);  
		System.out.println("The ASCII value of " + ch2 + " is: " + asciivalue2);
		System.out.println("The ASCII value of " + ch3 + " is: " + asciivalue3);  
		System.out.println("The ASCII value of " + ch4 + " is: " + asciivalue4);
	}

}
