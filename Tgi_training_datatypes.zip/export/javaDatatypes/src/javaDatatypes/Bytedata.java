package javaDatatypes;

public class Bytedata {

	
	/* byte byteVar;
Size: 1 byte (8 bits)

Values: -128 to 127

Default Value: 0
	 */
	
	
	public static void main(String[] args)
	{
		
		
		byte data= 126;
		 
        // byte is 8 bit value
		System.out.println("Byte data value:");
        System.out.println(data);
 
        data++;
        System.out.println("Byte data value after increment:");
        System.out.println(data);
 
        // It overflows here because
        // byte can hold values from -128 to 127
        System.out.println("Byte data value can hold values from -128 to 127:");
        data++;
        System.out.println(data);
 
        // Looping back within the range
        data++;
        System.out.println(data);
	}

}
