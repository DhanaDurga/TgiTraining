package javaDatatypes;

public class Stringdata {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
			
		//create string data type variable  
			String s1="Happy";  
			char ch[]={'D','I','W','A','L','I'};    
		//convert char array to string 
			String s2=new String(ch); 
		//create Java string data by new keyword    
			String s3=new String("to-All");
			System.out.print(s1+" ");    
			System.out.print(s2+" ");    
			System.out.print(s3);    
			
		
	}

}
