package javaDatatypes;

public class Variables {

	static int s=25;// static variables
	

	void local()
	{
		int l= 45;//local variable
		System.out.println("local variable:"+ l);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a =28;//instance variable
		System.out.println("instance variable:"+ a);
		System.out.println("static  variable:"+ s);
	Variables v= new Variables();
	v.local();

	
	}

}
