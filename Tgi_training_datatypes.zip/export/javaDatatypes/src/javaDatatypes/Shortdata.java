package javaDatatypes;

/*
 * short shortVar;
Size: 2 byte (16 bits)

Values: -32, 768 to 32, 767 (inclusive)

Default Value: 0
*/

public class Shortdata {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		short val1=22700;
		short val2=-10000;		short answer=(short)(val1-val2);
		System.out.println("Subtration of two short values:\n"+val1);
		System.out.println(val2);
		System.out.println("The answer is : "+answer);
		
		
		
		/*
		 * System.out.println(" short values:\n"+val1);
		 * System.out.println("Increase one by given short value:"); val1++;
		 * System.out.println(val1);
		 * System.out.println("Again Increase one by given short value:"); val1++;
		 * System.out.println(val1);
		 */
		
	}

}
