package JavaOperators;

public class AssignmentOperator 
{
		
	public static void main(String[] args)
	{
		int a=10;
		int b=5;
		int c=20;
		int d=10;
		int e=20;
		int f=10;

		// TODO Auto-generated method stub
		System.out.println("\nAssignment  Operators");
		System.out.println("\nvalue of a=10,b=5,c=20, d=10,e=20,f=10");
		System.out.println("\n a+=b:"+" "+(a+=b));
		System.out.println("\n c-=b:"+" "+(c-=b));
		System.out.println("\n d*=e:"+" "+(d*=e));
		System.out.println("\n e/=f:"+" "+(e/=f));
	}

}
