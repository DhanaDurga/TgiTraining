package JavaOperators;
import java.util.Scanner;

public class RelationalOperator {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 // create variables
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Compare two numbers using Relational operators");
	    System.out.println("Enter the two Integer values:");
	    int a=sc.nextInt();
	    int b=sc.nextInt();
	    // value of a and b
	    System.out.println("value1 is : " + a + " and value2 is : " + b);

	    // == operator
	    System.out.println("a == b is :"+(a == b));  // false

	    // != operator
	    System.out.println("a != b is :" +(a != b));  // true

	    // > operator
	    System.out.println("a > b is " +(a > b));  // false

	    // < operator
	    System.out.println("a < b is :"+(a < b));  // true

	    // >= operator
	    System.out.println("a >= b is :"+(a >= b));  // false

	    // <= operator
	    System.out.println("a <= b is :"+(a <= b));  // true
	  }
	
	}


