package JavaOperators;
import java.util.Scanner;

public class LogicalOperator 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 	Scanner sc=new Scanner(System.in);
		    System.out.println("Voters document verification to vote using Logical operators");
		    System.out.println("Enter your age :");
		    int a=sc.nextInt();
		    System.out.println("Enter your AadharNumber :");
		    long b =sc.nextLong();
		    //int length=b.Length();
		    if(a >=18 && b>0L)
		    	
		    {
		    	System.out.println("You are Eligible Person to vote.");
		    }
		    else if(a>=18 || b>0L)
		    {
		    	System.out.println("You are not Eligible Person to vote.");
		    }

	}

}
