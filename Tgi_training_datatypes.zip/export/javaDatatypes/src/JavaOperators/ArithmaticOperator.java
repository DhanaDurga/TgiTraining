package JavaOperators;

public class ArithmaticOperator {
	
	
	public static void main(String[] args) 
	{
		int a=15 ;
		int b=10;
		int c=5;
		// TODO Auto-generated method stub
		System.out.println("\nArithmetic Operators");
		System.out.println("a ,b and c values :"+ a +", " +b+" and "+c+" respectively");
		System.out.println("a+b:"+ (a+b));
		System.out.println("a-b:"+ (a-b));
		System.out.println("a*b:"+ a*b);
		System.out.println("a/b:"+ a/b);
		System.out.println("a%b:"+ a%b);
		System.out.println("Arithmatic Expression based Precedence (a+b/c-1):" +(a+b/c-1));
	}

}
