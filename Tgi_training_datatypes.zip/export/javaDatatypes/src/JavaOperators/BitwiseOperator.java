package JavaOperators;

public class BitwiseOperator
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int number1 = 12;
		int number2 = 25;
		int result;
		System.out.println("Bitwise Operation among values a=12 and b=25");
		
		//bitwise inclusive OR
		result = number1 | number2;
	    System.out.println("Bitwise OR (a|b):"+result); 
	    
	    //bitwise AND
	    result = number1 & number2;
	    System.out.println("Bitwise AND (a&b):"+result); 
	    result = number1 ^ number2;
	    
	    //bitwise exclusive OR
	    System.out.println("Bitwise XOR (a^b) :"+result); 
	    
	    //bitwise complement operator : n is -(n+1)
	    result = ~number1;
	    System.out.println("Bitwise Complement (~a)->(~12) :"+result); 
	    result = ~number2;
	    System.out.println("Bitwise Complement (~b)->(~25) :"+result); 
	    
	}

}
