package JavaOperators;

public class UnaryOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10, y= 5 ,a=7,b=13, c=20;
		boolean bb= true;
		
		
		System.out.println("variable values:\nx=10, y=5 , a=7, b=13 ");
		System.out.println("Unary operator: Prefix");
		System.out.println("++x:"+ ++x);
		System.out.println("--y:"+ --y);
		System.out.println("Unary operator: Postfix");
		System.out.println("a++:"+ a++);
		System.out.println("b--:"+ b--);
		System.out.println("After Postfix a and b values:");
		System.out.println("a++:"+ a++);
		System.out.println("b--:"+ b--);
		System.out.println("!of boolean value true is: "+!bb);//opposite of boolean value
	}

}
