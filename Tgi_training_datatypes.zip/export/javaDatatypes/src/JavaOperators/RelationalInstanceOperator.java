package JavaOperators;

public class RelationalInstanceOperator
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
			    String str = "Welcome All";
			    boolean result;

			    // checks if str is an instance of
			    // the String class
			    result = str instanceof String;
			    System.out.println("Instanceof Operator:");
			    System.out.println("Given String declaration is:  String str = Welcome All ");
			    System.out.println("Is str an object of String? " + result);
			
	}

}
