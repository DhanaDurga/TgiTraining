package JavaOperators;

public class ShiftOperator 
{

	public static void main(String[] args)
{
		// TODO Auto-generated method stub
		System.out.println("\nshift Operators");
		System.out.println("10<<2:"+(10<<2));//10*2^2=10*4=40
		System.out.println("10<<3:"+(10<<3));//10*2^3=10*8=80
		System.out.println("20>>2:"+(20>>2));//20/2^2=20/4=5
		System.out.println("24>>2:"+(24>>3));//24/2^3=24/8=3
		
		 //For positive number, >> and >>> works same 
		System.out.println("\nFor positive number, >> and >>> works same ");
		System.out.println("44>>2:"+(44>>2));//44/2^2=44/4=11
		System.out.println("44>>>2:"+(44>>>2));//44/2^2=44*4=11
		
		 //For negative number, >>> changes parity bit (MSB) to 0  
		System.out.println("\nFor negative number, >>> changes parity bit (MSB) to 0");
	    System.out.println("-20>>2:"+(-20>>2));  
	    System.out.println("-20>>>2:"+(-20>>>2));  
	}

}
