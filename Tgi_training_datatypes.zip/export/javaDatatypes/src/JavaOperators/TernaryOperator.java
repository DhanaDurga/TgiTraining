package JavaOperators;

public class TernaryOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=5;
		
			System.out.println("\n Ternary Operators :3 operands condition=> (a<b)? a:b ");
			System.out.println("a and b values:"+a +" and "+ b );
			int value=(a<b)? a:b;
			if(a== value)
			System.out.println("condition true so print 1st value:"+ a);	
			else
			System.out.println("condition false so print 2nd value:"+ b);
	

	}

}
