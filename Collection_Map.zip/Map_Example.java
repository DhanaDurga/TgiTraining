package com.test.collections;

import java.util.HashMap;
import java.util.Map;

class ClassDetails
{
	//com.test.collections.Student cannot be cast to java.lang.Comparable
	int rollno;
	String name;
	char sec;
	ClassDetails(char sec ,String name,int rollno)
	{
		this.sec=sec;
		this.name=name;
		this.rollno=rollno;
		
	}
}
public class Map_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			//creating Map to ClassDetails
			System.out.println("creating Map to ClassDetails");
			Map<Integer,ClassDetails> obj=new HashMap<Integer,ClassDetails>();
			
			//creating ClassDetails
			System.out.println("creating ClassDetails");
			ClassDetails s1=new ClassDetails('B',"Dhana",452);
			ClassDetails s2=new ClassDetails('A',"Malar",460);
			ClassDetails s3=new ClassDetails('C',"Kavin",512);
			
			//Adding ClassDetails to Map using put() method
			System.out.println("Adding ClassDetails to Map using put() method");
			obj.put(1, s1);
			obj.put(2, s2);
			obj.put(3, s3);
			
			System.out.println("");
			 System.out.println("Key"+" "+"Section"+" "+"Name"+"  "+"RollNo");
			 for(Map.Entry<Integer,ClassDetails> s:obj.entrySet())
			 {  
				 int key=s.getKey();
				 ClassDetails sobj=s.getValue();
				 
				 //Printing keys and values
				
				 System.out.println(key+":   "+sobj.sec+"      "+sobj.name+"   "+sobj.rollno);
			 }  
			 
			 System.out.println("");
			 System.out.println(" getClass() method =>"+obj.getClass());
			 
			 System.out.println(" ");
			 System.out.println("Updation in the Map of ClassDetails ");
			
			 //Direct update in the Map without using replaceMethod()
			 ClassDetails ch=obj.get(2);
			 ch.name="Mala";
			 for(Map.Entry<Integer,ClassDetails> s:obj.entrySet())
			 {  
				 int key=s.getKey();
				 ClassDetails sobj=s.getValue();
				 
				 //Printing keys and values
				
				 System.out.println(key+":   "+sobj.sec+"      "+sobj.name+"   "+sobj.rollno);
			 }
			 
			 
			 System.out.println("");
			 obj.remove(3);
			 System.out.println("After using remove(3) method the Map is:");
			 for(Map.Entry<Integer,ClassDetails> s:obj.entrySet())
			 {  
				 int key=s.getKey();
				 ClassDetails sobj=s.getValue();
				 
				 //Printing keys and values
				
				 System.out.println(key+":   "+sobj.sec+"      "+sobj.name+"   "+sobj.rollno);
			 }
			 System.out.println("");
			 System.out.println("Using get(1) Method - to retrieve the details must know the Key : ");
			 ClassDetails o=obj.get(1);
			 System.out.println(o.sec+" "+o.name+" "+o.rollno);
			 
			
			 
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

}
