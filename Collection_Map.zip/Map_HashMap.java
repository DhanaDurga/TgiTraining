package com.test.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.test.objcreation.newkey;

public class Map_HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			// Default Initialization of a Map
		Map<Character,String> classlist=new HashMap();
		
		// Initialization of a Map using Generics
		Map<Character,String> classlist1=new HashMap<Character,String>();
	
		/*
		 * Map<Integer,String> list=new HashMap<Integer,String>();
		 * list.put(241,"Dhana"); list.put(451,"Kala"); System.out.println(list);
		 * System.out.println(list.keySet()); System.out.println(list.values());
		 * System.out.println(list.entrySet());
		 */
		//Using put() method to insert the element in Map
		classlist.put('D',"Riya");
		classlist.put('A',"DIya");
		classlist.put('E',"Durga");
		classlist.put('A',"Diya");
		classlist.put(null,"Mala");
		classlist.put('F',null);
		
		classlist1.put(new Character('B'),"Maryn");
		classlist1.put('c',"Jeswi");
		classlist1.put('G', null);
		System.out.println(" Key Sections Map with values Student");
		System.out.println("HashMap have one null key and multiple null values");
		System.out.println("");
		System.out.println("The classlist \"A\" Section details : " +classlist);
		System.out.println("In Map duplicate key values are not allowed");
		System.out.println("The keys are : "+classlist.keySet());
		System.out.println("The values are : "+classlist.values());
		System.out.println("The classlist \"B\" section details :"+classlist1.entrySet());
		System.out.println("");
		
		//Using putAll() method +c
		classlist.putAll(classlist1);
		System.out.println("After putAll() method process the Map is :");
		// // Traversing through Map using for-each loop
		for(Map.Entry<Character,String> map : classlist.entrySet())
		{
			Character key= map.getKey();
			String value=map.getValue();
			//Class<? extends Entry> cla=map.getClass();
			
			//Printing  key and values
			System.out.println(key +" :"+ value+" ");
		}
		classlist.putIfAbsent('F',"Liya");
		System.out.println("");
		System.out.println("classlist.putIfAbsent('F',\"Liya\");");
		System.out.println("After using putIfAbsent() - the key is inserted if it is not in Map => "+classlist);
		System.out.println("Using get(D) method value is : "+classlist.get('D'));
		System.out.println("Using replace(A,Ammu) => "+classlist.replace('A', "Ammu"));
		System.out.println("After changing :"+classlist);
		
		System.out.println("");
		System.out.println("Calculate the Index value");
		System.out.println("Hashcode :"+classlist.hashCode());
		int code=classlist.hashCode();
		int index=code&(classlist.size()-1);
		System.out.println(index);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}

}
