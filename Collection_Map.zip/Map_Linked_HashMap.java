package com.test.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

class Book {    
	int id;    
	String name,author,publisher;    
	int quantity;    
	public Book( int id,String name, String author, String publisher, int quantity) 
	{    
	    this.id=id; 
	    this.name = name;    
	    this.author = author;    
	    this.publisher = publisher;    
	    this.quantity = quantity;    
	}    
	}    
public class Map_Linked_HashMap
{

	public static void main(String[] args) 
	{
		System.out.println("Map_Linked_HAshMap -maintains insertion order.");
		 try
		 {
		    //Creating map of Books    
		    Map<Integer,Book> map=new LinkedHashMap<Integer,Book>();   
		    System.out.println("");
		    System.out.println("Map is : "+map);
		    System.out.println("isEmpty() is : "+map.isEmpty());
		    System.out.println("Size() is : "+map.size());
		    System.out.println("");
		   
		    //Creating Books    
		    Book b1=new Book(121,"Let us C","Yashwant Kanetkar","BPB",8);    
		    Book b2=new Book(132,"Data Communications & Networking","Forouzan","Mc Graw Hill",4);    
		    Book b3=new Book(150,"Operating System","Galvin","Wiley",6);    
		    //Adding Books to map   
		    map.put(132,b2);  
		    map.put(121,b1);  
		    map.put(150,b3);  
		      
		    //System.out.println("Id"+"          "+"BookName"+"           "+"Author"+"        "+"Publisher"+"     "+"Quantity");
		    //Traversing map  
		    for(Map.Entry<Integer, Book> entry:map.entrySet())
		    {    
		        int key=entry.getKey();  
		        Book b=entry.getValue();  
		        System.out.println("Book Id "+key+" Details:");  
		      
		        System.out.println(b.id+"   "+b.name+"   "+b.author+"   "+b.publisher+"  "+b.quantity);   
		    }   
		    System.out.println("");
		    System.out.println("Map is : "+map);
		    System.out.println("isEmpty() is : "+map.isEmpty());
		    System.out.println("Size() is : "+map.size());
		    
		    System.out.println("");
		    System.out.println("Keys : "+map.keySet());
		    System.out.println("containsKey(121) is :"+map.containsKey(121));
		    System.out.println("containsKey(100) is :"+map.containsKey(100));
		    System.out.println();
		    
		  System.out.println("");
		  ArrayList<Object> l1=new ArrayList<Object>();
		  ArrayList<Object> l2=new ArrayList<Object>();
		  for(Map.Entry<Integer, Book> entry:map.entrySet())
		    {  
			 Book bo=entry.getValue();
			  l1.add(bo.name);
			  l2.add(bo.id);			  
		    }
		  System.out.println("Book Id List is : "+l2);
		  System.out.println("Books Name list is : "+l1);
		  System.out.println("containsValue(b1) is : "+map.containsValue(b1));
		  

		  System.out.println("");
		  System.out.println("After iteration of Book Id list is :");
		  Iterator<Object> id=l2.iterator();
		  while(id.hasNext())
		  {
			  System.out.println(id.next());
		  }
		  
		  
		  System.out.println("");
		  System.out.println("After iteration of Book name list is :");
		  Iterator<Object> name=l1.iterator();
		  while(name.hasNext())
		  {
			  System.out.println(name.next());
		  }
	
		  
		    
		 }
		 catch(Exception e)
		 {
			 System.out.println(e.getMessage());
		 }
		}    
		  

}
