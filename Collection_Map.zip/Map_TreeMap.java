package com.test.collections;

import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;

public class Map_TreeMap {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Tree Map-NavigatableMap and SortedMap - TreeMap maintains ascending order based keys");
		System.out.println("Tree Map have multiple null values but no null keys");
		System.out.println("");
		try
		{
			
		Map<Integer,String> map=new TreeMap<Integer,String>();
		TreeMap<Integer,String> tmap=new TreeMap<Integer,String>();
		NavigableMap<Integer,String> nmap=new TreeMap<Integer,String>();
		SortedMap<Integer,String> smap=new TreeMap<Integer,String>();

		map.put(12, "Dhana");
		map.put(10, null);
		tmap.put(20, "Ammu");
		tmap.put(100, "Amit");
		nmap.put(102, "Ravi");
		nmap.put(90,"venu");
		nmap.put(105,"Karthi");
		smap.put(101, "Vijay");
		smap.put(103, "Rahul");
		smap.put(97,"Bala");
		
		//Tree Map have multiple null values but no null keys
		//tmap.put(null,"mala");
		
		
		System.out.println(map);
		System.out.println("Traversing key and values using foreach");
		for(Map.Entry m:map.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }    
		System.out.println("");
		System.out.println("TreeMap -tmap");
		System.out.println(tmap);
		System.out.println("");
		System.out.println("Navigatable Map -nmap");
		System.out.println(nmap);
		System.out.println("");
		System.out.println("Sorted Map - smap ");
		System.out.println(smap);
		
		
		System.out.println("");
		System.out.println("Methods - sorting and accessing Map");
		System.out.println("nmap.descendingKeySet(); => Maintains descending order  ");
		System.out.println("Descending keys are : " +nmap.descendingKeySet());
		System.out.println("");
		System.out.println("nmap.headMap(100,false) => Returns key-value pairs whose keys are less than or equal to the specified key. "+"\n"+nmap.headMap(100, false));
		System.out.println("");
		System.out.println("smap.tailMap(101); =>Returns key-value pairs whose keys are greater than or equal to the specified key.  "+"\n"+smap.tailMap(101));
		System.out.println("");
		System.out.println("smap.subMap(90,100); => Returns key-value pairs exists in between the specified key.  ");
		System.out.println(smap.subMap(90, 100));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
}

}
