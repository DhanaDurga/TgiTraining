package com.test.abstraction;
interface age
{
	void checkage();
}
interface aadhar
{
	void checkaadhar();
	
}
class voter implements age,aadhar //interface allowed multiple inheritance
{
	public void checkage()
	{
		System.out.println("Multiple Inheritance -One class implements two interfaces");
		System.out.println();
		int a=30;
		System.out.println("Your age was "+a);
		if(a>=18)
		{
			System.out.println("You are eligible to voting");
		}
		else
			System.out.println("You are not eligible to voting");
	}
	public void checkaadhar()
	{
		int a=1245462;
		System.out.println(" ");
		System.out.println("Your Aadhar number was "+a);
		if(a>0)
		{
			System.out.println("You are eligible to voting");
			
		}
		else
			System.out.println("You are not eligible to voting");
	}
}
public class InterfaceMultipleInheritance
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		age ageobj=new voter();
		aadhar aadharobj=new voter();
		ageobj.checkage();
		aadharobj.checkaadhar();

	}

}
