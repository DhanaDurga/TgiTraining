package com.test.abstraction;
interface sub//Having static method
{
	void getsub();
}
interface add 
{
	void getadd();
	
}
interface circle extends sub , add
{
		double pi=3.14;
		static double getcircle(int x)
		{
			return (pi*x*x);
		}
		
}
class works implements circle
{
	

	@Override
	public void getsub() {
		// TODO Auto-generated method stub
		System.out.println("The subtraction of two numbers (45,12) is :"+(45-12));
				
		
	}

	@Override
	public void getadd() {
		// TODO Auto-generated method stub
		System.out.println("The addition of two numbers (45,12) is :"+(45+12));
	}
}
public class InterfaceExtendsInterface 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Interface extends interfaces -Multipe Inheritance");
		System.out.println(" ");
		sub subobj =new works();
		subobj.getsub();
		add addobj=new works();
		addobj.getadd();
		System.out.println(" ");
		System.out.println("we execute the static interface method getcircle()");
		System.out.println("The area of circle is (radius =5) :"+circle.getcircle(5));
		
	}

}
