package com.test.abstraction;

abstract class MainAbstract
{
String str;
	
	//Abstract class containing the constructor
	MainAbstract(String str)
	{
		this.str=str;
		System.out.println("Abstract method  have Constructor.");
		System.out.println("The string passed trough constructor was : "+str);
		System.out.println(" ");
	}
	
	//Abstract class containing overloaded abstract methods
	abstract void method();
	abstract void method(String str);
	
	//non -abstract method
	void display()
	{
		System.out.println("Invoked non abstract method - implementation is inside the abstract class");
		System.out.println("Abstract class also can have non abstract methods.");
		System.out.println("");
	}
	
}

class NonAbstractClass extends MainAbstract
{
	
	NonAbstractClass(String str)
	{
		super(str);
	}
	// override abstract method
	void method()
	{
		System.out.println("Invoked Abstract method");
		System.out.println("Java abstract keyword is used to declare an abstract class.");
		System.out.println("");
	}
	
	void method(String str)
	{
		System.out.println("Invoked overloaded Abstract method.");
		System.out.println("The Message was :");
		System.out.println(str);
	}
	
}

public class AbstractClass 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		NonAbstractClass obj= new NonAbstractClass("Constructor is Invoked");
		obj.method();
		obj.display();
		obj.method("String Parameter passed through overloaded abstract method");
	}

}
