package com.test.abstraction;
interface bank
{
	int sbi();
	int IOB();
	
	
}

abstract class bankinterest implements bank //Abstract Class implements interface
{
	abstract double pnb();//abstract method

	@Override
	public int sbi() //Abstract class can provide the implementation of interface.
	{
		// TODO Auto-generated method stub
		
		return 7;
		
	}
}
class example extends bankinterest
{

	@Override
	public int IOB() 
	{
		// TODO Auto-generated method stub
		return 6;
	}

	@Override
	 double pnb() //abstract class method
	{
		// TODO Auto-generated method stub
		return 6.5;
	}

}

public class AbstractClassImplementsInterface 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Abstract Class implements interface");
		System.out.println(" Abstract class can provide the implementation of interface.. ");
		System.out.println(" ");
		bankinterest obj=new example();
		//bank obj=new example();
		System.out.println("SBI Bank Rate of interest is : "+obj.sbi()+"%");
		System.out.println("IOB Bank Rate of interest is : "+obj.IOB()+"%");
		System.out.println("PNB Bank Rate of interest is : "+obj.pnb()+"%");
	}

}	
