package com.test.abstraction;
interface college
{
	void clgname();
	
		
	interface department
	
	{
		void dept();
	}
}

public class NestedInterface  implements college.department
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Nested Interface - Interface declared within another interface or class, is known as a nested interface. ");
		System.out.println(" ");
		college.department obj=new NestedInterface();
		obj.dept();
	}

	@Override
	public void dept() {
		// TODO Auto-generated method stub
		System.out.println("Welcome to Anna University");
		System.out.println("The Department list : ");
		System.out.println(" CSE ");
		System.out.println(" IT ");
		System.out.println(" ECE ");
	}
		
	}


