package com.test.polymorphism;

public class StaticBinding 
{
	private void eat()
	{
		System.out.println("Animals are eating.... ");
	}
	final void sound()
	{
		System.out.println("Dogs are Barking.... ");
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Static Binding - Determined by Compile time");
		System.out.println("private, final or static method in a class, there is static binding");
		System.out.println(" ");
		StaticBinding obj=new StaticBinding();
		obj.eat();
		obj.sound();
	}

}
