package com.test.polymorphism;

public class MethodOverloadingChangingDatatype 
{
	static int c;
	static int add(int a ,int b)
	{
		
		return c=a+b;
	}

	static double add(double a, double b)
	{
		double y;
		return y = (a + b);
	}
	static int add(char a,char b)
	{
		int z;
		return z=(a+b);
	}
	 
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int a='A';
		int b='B';
		System.out.println("Method Overloading - changing Data Types of Arguments");
		System.out.println("");
		System.out.println("Method add(45,30) passing two integer parameters");
		System.out.println("The answer is : "+add(45,30));
		System.out.println(" ");
		System.out.println("Method add(4.5,3.2) passing two double parameters");
		System.out.println("The answer is : "+add(4.5,3.2));
		System.out.println(" ");
		System.out.println("Method add(12,5.5) passing  two parameter data types is int and double ");
		System.out.println("Type-promotion -Here the int data type is promoted to double data type");
		System.out.println("The answer is : "+add(12,5.5));
		System.out.println(" ");
		System.out.println("Method add(6.6,5) passing  two parameter data types is double and int ");
		System.out.println("Type-promotion -Here the int data type is promoted to double data type");
		System.out.println("The answer is : "+add(6.6,5));
		System.out.println(" ");
		System.out.println("Method add(A,B) passing two char parameters");
		System.out.println("The value of A is : "+a);
		System.out.println("The value of B is : "+b);
		System.out.println("The answer is : "+add('A','B'));
		


	}

}
