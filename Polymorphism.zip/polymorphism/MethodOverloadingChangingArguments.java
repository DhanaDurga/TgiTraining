package com.test.polymorphism;

public class MethodOverloadingChangingArguments 
{
	static int c;
	static int add(int a ,int b)
	{
		
		return c=a+b; 
	}
	static int add(int a,int b,int c)
	{
		return c=(a+b+c);
	}
	static int add(int a,int b,int c,int d)
	{
		return c=(a+b+c+d);
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println("Method Overloading - changing no of Arguments");
		System.out.println("");
		System.out.println("Method add(45,30) passing two parameters");
		System.out.println("The answer is : "+add(45,30));
		System.out.println(" ");
		System.out.println("Method add(45,30,25) passing three parameters");
		System.out.println("The answer is : "+add(45,30,25));
		System.out.println(" ");
		System.out.println("Method add(45,30,25,50) passing four parameters");
		System.out.println("The answer is : "+add(45,30,25,50));

	}

}
