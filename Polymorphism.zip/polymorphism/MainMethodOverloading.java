package com.test.polymorphism;

public class MainMethodOverloading 
{

	public static void main(String[] args) 
	{ 
		// TODO Auto-generated method stub
		System.out.println("Main Method is not Overloading because it's a static method");
		System.out.println("JVM calls main() method which receives string array as arguments only");
		System.out.println(" ");
		System.out.println("Main Method with String[]");

	}
	 
	public static void main(String args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Main Method with String ");

	}
	public static void main() 
	{
		// TODO Auto-generated method stub
		System.out.println("Main Method without arguments");

	}
	
}
