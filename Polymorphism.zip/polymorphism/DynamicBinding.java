package com.test.polymorphism;
class Animal
{
	void eat()
	{
		System.out.println("Animals are eating,,,,");
	}
}
class Dog extends Animal
{
	void eat()
	{
		System.out.println("Dogs are eating,,,,");
	}
}
public class DynamicBinding 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Dynamic Binding - Determined by Runtime");
		System.out.println("Object type cannot be determined by the compiler");
		System.out.println("Because the instance of Dog is also an instance of Animal.");
		System.out.println(" ");
		Animal obj=new Dog();
		obj.eat();

	}

}
