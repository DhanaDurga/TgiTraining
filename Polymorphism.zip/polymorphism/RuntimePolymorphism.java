package com.test.polymorphism;
class Shape
{
	void draw()
	{
		System.out.println("Drawing Shapes.....");
	}
}
class Rectangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Rectangle Shapes.....");
	}
}
class Circle extends Shape
{
	void draw() 
	{
		System.out.println("Drawing Circle Shapes.....");
	}

}
class Triangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Triangle Shapes.....");
	}
}
public class RuntimePolymorphism
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Runtime Polymorphism -Method Overriding with Hierarchical Inheritance");
		System.out.println(" ");
		Shape obj;
		obj=new Rectangle();
		obj.draw();
		obj=new Circle();
		obj.draw();
		obj=new Triangle();
		obj.draw();
		
		
	}

}
