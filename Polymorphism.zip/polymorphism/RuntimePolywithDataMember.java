package com.test.polymorphism;
class carspeed
{
	int carlimit=80;
	
}
class bikespeed extends carspeed
{
	int bikelimit=50;
	
}
public class RuntimePolywithDataMember
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println("Runtime Polymorphism can't be achieved by data members.");
		System.out.println("carlimit=80 and  bikelimit=50");
		System.out.println("");
		carspeed obj=new bikespeed();//upcasting
		//bikespeed obj1=new bikespeed();
		System.out.println("The bike speed limit is :"+obj.carlimit);
		//System.out.println("The Bike speed limit is :"+obj1.bikelimit);
	}

}
