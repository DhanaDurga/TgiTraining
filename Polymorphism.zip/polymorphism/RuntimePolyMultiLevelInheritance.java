package com.test.polymorphism;
class ShapeDrawing
{
	void draw()
	{
		System.out.println("Drawing Shapes.....");
	}
}
class Square extends ShapeDrawing
{
	
	/*
	 * void draw() { System.out.println("Drawing Square Shapes....."); }
	 */
}
class Star extends Square
{
	void draw()
	{
		System.out.println("Drawing Star Shapes.....");
	}
}
public class RuntimePolyMultiLevelInheritance
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Runtime Polymorphism with MultiLevel Inheritance");
		System.out.println("If a class was not overriding a method ,the super class method was invoked");
		System.out.println(" ");
		ShapeDrawing obj;
		obj=new Square();
		obj.draw();
		obj=new Star();
		obj.draw();

	}

}
