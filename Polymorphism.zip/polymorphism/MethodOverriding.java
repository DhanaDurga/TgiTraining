package com.test.polymorphism;
class Postal
{
	float getrateofinterest()
	
	{
		System.out.println("");
		return 0;
	}
}
class SSY extends Postal
{
	float getrateofinterest() //method overriding
	{
		return (float)7.6;
	}
	
}

class NSC extends Postal
{
	float getrateofinterest()//method overriding
	{
		return (float)6.8;
	}
}
class PPF extends Postal
{
	float getrateofinterest()//method overriding
	{
		return (float)7.1;
	}
}
public class MethodOverriding 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Method Overriding -where three classes are overriding the method of a parent class.");
		float a= new SSY().getrateofinterest();
		float b= new NSC().getrateofinterest();
		float c= new PPF().getrateofinterest();
		System.out.println(" ");
		System.out.println("Postal Dpartment Schemes RateOfInterest Details :");
		System.out.println("The SSY Account RateOfInterest is : "+a);
		System.out.println("The NSC Account RateOfInterest is : "+b);
		System.out.println("The PPF Account RateOfInterest is : "+c);

		

	}

}
