package com.test.inheritancetypes;

public class Student1Details 
{
	String name="Dhana";
	int rollno=344;
	String department="CSE";
	
	public void display()
	{
		
		System.out.println("Student1 Details");
		System.out.println("Name :"+name);
		System.out.println("Rollno :"+rollno);
		System.out.println("Department :"+department);
	}
}
