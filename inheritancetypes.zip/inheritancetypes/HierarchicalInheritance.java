package com.test.inheritancetypes;
class college 
{
void col()
	{
	System.out.println("Anna University Welcomes you all ");
	}
}
 class Student1Info extends college
{
	String name="Dhana";
	int rollno=344;
	String department="CSE";
	
	public void display()
	{
		
		System.out.println("Student1 Details");
		System.out.println("Name :"+name);
		System.out.println("Rollno :"+rollno);
		System.out.println("Department :"+department);
	}
}
 class Student2Info extends college
 {
 	String name="Malar";
 	int rollno=350;
 	String department="IT";
 	
 	public void view()
 	{
 		System.out.println("Student2 Details");
 		System.out.println("Name :"+name);
 		System.out.println("Rollno :"+rollno);
 		System.out.println("Department :"+department);
 	}
 }
 class Student3Info extends college
 {
 	String name="vihan";
 	int rollno=354;
 	String department="CSE";
 	
 	public void info()
 	{
 		System.out.println("Student3 Details");
 		System.out.println("Name :"+name);
 		System.out.println("Rollno :"+rollno);
 		System.out.println("Department :"+department);
 	}
 }


public class HierarchicalInheritance 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Hierarchical Inheritance -class Student1info and student2info both are extends the same class college");
		System.out.println("create object for the child class student2info to invoke the parent class methods");
		System.out.println(" ");
		Student2Info student2obj=new Student2Info();
		student2obj.col();
		student2obj.view();
		System.out.println(" ");
		System.out.println("create object for the child class student3info to invoke the parent class methods");
		System.out.println(" ");
		Student3Info student3obj=new Student3Info();
		student3obj.col();
		student3obj.info();
		

	}

}
