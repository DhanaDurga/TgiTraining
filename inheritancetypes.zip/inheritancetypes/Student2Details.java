package com.test.inheritancetypes;

public class Student2Details extends Student1Details
{
	String name="Malar";
	int rollno=350;
	String department="IT";
	
	public void view()
	{
		System.out.println("Student2 Details");
		System.out.println("Name :"+name);
		System.out.println("Rollno :"+rollno);
		System.out.println("Department :"+department);
	}
}
