package com.test.inheritancetypes;

public class MultilevelInheritance 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("MultiLevel Inheritance - Object created for Student3 Details class");
		System.out.println("Student3Details class extends the Student2Details class");
		System.out.println("Student2Details class extends the Student1 Details class");
		System.out.println(" ");
		Student3Details obj=new Student3Details();
		obj.display();
		System.out.println(" ");
		obj.view();
		System.out.println(" ");
		obj.info();
	}

}
