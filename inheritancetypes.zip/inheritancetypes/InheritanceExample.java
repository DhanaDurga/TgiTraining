package com.test.inheritancetypes;

public class InheritanceExample 
{
	public static void main(String[] args)
	{
		Student2Details obj=new Student2Details();
		System.out.println("Single Inheritance - Object created for Student2 Details class");
		System.out.println("Student2 Details Class extended the Student1 Details class");
		System.out.println("");
		obj.display();
	}
}
