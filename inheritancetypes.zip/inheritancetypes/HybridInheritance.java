package com.test.inheritancetypes;
class Department 
{
void col()
	{
	System.out.println("Anna University Welcomes you all           //Single level inheritance");
	
	}
}
class BestStudent extends  Department
{
	void list()
	{
		System.out.println(" ");
		System.out.println("CSE and IT department Best Student is :Malar              //Hierarchical inheritance");
	}
}

 class Student1Data extends BestStudent
{
	String name="Dhana";
	int rollno=344;
	String depart="CSE";
	
	public void display()
	{
		
		System.out.println("Student1 Details");
		System.out.println("Name :"+name);
		System.out.println("Rollno :"+rollno);
		System.out.println("Department :"+depart);
	}
}
 class Student2Data extends BestStudent
 {
 	String name="Malar";
 	int rollno=350;
 	String depart="IT";
 	
 	public void view()
 	{
 		System.out.println("Student2 Details");
 		System.out.println("Name :"+name);
 		System.out.println("Rollno :"+rollno);
 		System.out.println("Department :"+depart);
 	}
 }

class Student3Data  extends BestStudent
	  { 
			String name = "vihan";
			int rollno = 354;
			String depart = "CSE";

			public void info() 
			{
				System.out.println("Student3 Details");
				System.out.println("Name :" + name);
				System.out.println("Rollno :" + rollno);
				System.out.println("Department :" + depart);
			}
}
	 
 
public class HybridInheritance 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println("Hybrid Inheritance - Multiple types of inheritance in a single structure.");
		System.out.println("Hybrid Inheritance with help of single and Hieraechical Inheritance");
		System.out.println("");
		BestStudent singleobj=new BestStudent();
		singleobj.col();
		Student2Data hierarchiobj=new Student2Data();
		hierarchiobj.list();		
		hierarchiobj.view();
		
		
		
			
	}

}
