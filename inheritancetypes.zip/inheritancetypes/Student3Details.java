package com.test.inheritancetypes;

public class Student3Details extends Student2Details
{
	String name="vihan";
	int rollno=354;
	String department="CSE";
	
	public void info()
	{
		System.out.println("Student3 Details");
		System.out.println("Name :"+name);
		System.out.println("Rollno :"+rollno);
		System.out.println("Department :"+department);
	}
}
