package com.test.objcreation;

public class NewInstanceExample 
{
	void show()    
	{    
	System.out.println("A new object created using newinstance() method.");    
	}  
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
				 
		try  
		{  
			/*
			 * //creating an instance of Class class Class cls =
			 * Class.forName("com.test.objcreation.NewInstanceExample");
			 * 
			 * //creates an instance of the class using the newInstance() method
			 * NewInstanceExample obj = (NewInstanceExample) Cls.newInstance();
			 */
		String path="com.test.objcreation.NewInstanceExample";
			 NewInstanceExample obj = (NewInstanceExample) Class.forName(path).newInstance();
		//invoking the show() method  
		obj.show();   
		}   
		catch (ClassNotFoundException |  InstantiationException | IllegalAccessException e )
		{   
		e.printStackTrace();   
		}   
			

	}

}
