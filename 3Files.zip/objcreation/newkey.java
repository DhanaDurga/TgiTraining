package com.test.objcreation;

public class newkey 
{
static void display() 
	{
		System.out.println("Object created using new keyword");
	}

static void view()
{
	System.out.println("Creating multiple objects by one type only");
}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		newkey nk1=new newkey();
		newkey nk2=new newkey(),nk3=new newkey();
		
		display();
		nk3.view();
	}

}
