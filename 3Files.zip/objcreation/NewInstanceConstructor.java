package com.test.objcreation;
import java.lang.reflect.Constructor;
public class NewInstanceConstructor
{
	private String str;  
	
	 
	NewInstanceConstructor()   
	{   
	} 
	public String getName()   
	{   
	return str;   
	}   
	
	public void setName(String str)   
	{   
	this.str = str;   
	}   
	void view() 
	{
		System.out.println("Using newInstance() Method of Constructor class we create a object");
		System.out.println("Using that object to viewed the information was : ");
	}
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		try  
		{   
		Constructor<NewInstanceConstructor> constructorobj = NewInstanceConstructor.class.getDeclaredConstructor();   
		NewInstanceConstructor obj = constructorobj.newInstance();   
		obj.setName("Welcome All to TGI Family");
		obj.view();
		System.out.println(obj.getName());   
		}   
		
		catch (Exception e)   
		{   
		e.printStackTrace();   
		}   
		
	}

}
