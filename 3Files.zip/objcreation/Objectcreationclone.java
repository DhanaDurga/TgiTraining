package com.test.objcreation;

public class Objectcreationclone implements Cloneable
{
	@Override  
	protected Object clone() throws CloneNotSupportedException   
	{   
	//invokes the clone() method of the super class      
	return super.clone();   
	}   
	String str = "New Object Created using Clone method";   
public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		//Object creation using new keyword
		Objectcreationclone obj=new Objectcreationclone();
		try  
		{  
		//creating a new object of the obj1 suing the clone() method  
			Objectcreationclone newobj = (Objectcreationclone) obj.clone();   
		System.out.println(newobj.str);   
		}   
		catch (CloneNotSupportedException e)   
		{   
		e.printStackTrace();   
		}   
		
	}

}
   

 