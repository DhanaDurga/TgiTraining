package com.test.objcreation;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeserializationExample 

{
	public static void main(String args[])
	{
String filepath="C:\\Users\\Public\\Documents\\AccDetails.txt";
		
		
		
		try  
		{    
		
			  
		//Creates a stream and writes the object    
		FileInputStream fin=new FileInputStream(filepath);    
		ObjectInputStream in=new ObjectInputStream(fin);    
		AccountDetails obj=(AccountDetails)in.readObject();    
		
		System.out.println("Successfully readed the bytecode file");  
		
		System.out.println("The file contains following data :");
		
		System.out.println(obj.getName());
		System.out.println(obj.getBalance());
		//out.flush();    
		//closes the output stream    
		in.close();    
		
		
		}  
		catch(Exception e)  
		{  
		System.out.println(e);  
		}    
	}
	
}


