package com.test.objcreation;

import java.io.Serializable;

public class AccountDetails implements Serializable
	{

		
			// TODO Auto-generated method stub
			private int balance=50;  
			private String name="Dhana";  
			AccountDetails(String name ,int balance)
			{
				this.name=name;
				this.balance=balance;
			}
			public int getBalance()    //accessor method  
				{  
				return balance;  
				}  
			public void setBalance(int incre) //mutator method  
				{  
				balance += incre;  
				}  
			public String getName()   
				{  
				return name;  
				}  
			public void setName(String name)   
				{  
				this.name = name;  
				}  
			public void display()  
				{  
					 
					System.out.println("Student name: "+name);
					System.out.println("Account Balance.: "+balance); 
				}  

		

	}


