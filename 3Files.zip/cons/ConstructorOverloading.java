package com.test.cons;

public class ConstructorOverloading 
{
	String bookname;
	String author;
	int code;
	ConstructorOverloading(String bookname,String author)
	{
		this.bookname=bookname;
		this.author=author;
	}
	ConstructorOverloading(String bookname,String author,int code)
	{
		this.bookname=bookname;
		this.author=author;
		this.code=code;
	}
	void display()
	{
		System.out.println("Book Details: Name  Author and code ");
		System.out.println( bookname +"  " + author +"  " +code);
	}
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ConstructorOverloading obj1=new ConstructorOverloading("PonniyanSelvan","Kalki");
		ConstructorOverloading obj2=new ConstructorOverloading("PonniyanSelvan","Kalki",1850);
		System.out.println("Constructor Overloading - two parameterized constructor");
		obj1.display();
		System.out.println("");
		System.out.println("Constructor Overloading - three parameterized constructor");
		obj2.display();

	}

}
