package com.test.cons;
class ConstructKey
{ 
	String msg;
	ConstructKey (String msg)
	{	
		this.msg=msg;
		System.out.println("parameterized constructor");
		System.out.println("Constructors invoked when the instance of class created");
		System.out.println();
		System.out.println("The message is : "+msg);
	}

}

public class ParameterizedConstructor
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ConstructKey obj = new ConstructKey("Welcome");

	}

}
