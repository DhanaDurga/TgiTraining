package com.test.cons;
class bookdetails implements Cloneable
{
	String bookname;
	String author;
	int code;
	protected Object clone() throws CloneNotSupportedException   
	{   
	//invokes the clone() method of the super class      
	return super.clone();   
	}  
	bookdetails()
	{
		
	}
	bookdetails(String bookname,String author)
	{
		this.bookname=bookname;
		this.author=author;
	}
	bookdetails(String bookname,String author,int code)
	{
		this.bookname=bookname;
		this.author=author;
		this.code=code;
	}
	bookdetails(bookdetails obj)
	{
		bookname=obj.bookname;
		author=obj.author;
		code=obj.code;
	}
	void display()
	{
		System.out.println("Book Details: Name  Author and code ");
		System.out.println( bookname +"  " + author +"  " +code);
	}
}
public class CopyConstructor 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println("Object1 details : bookname=PonniyanSelvan Author=Kalki");
		System.out.println("Object2 details : bookname=PonniyanSelvan Author=Kalki code=1850");
		System.out.println("");
		bookdetails obj1=new bookdetails("PonniyanSelvan","Kalki");
		bookdetails obj2=new bookdetails("PonniyanSelvan","Kalki",1850);
		System.out.println("create object3 using constructor to copy values from object1");
		System.out.println("object3=new bookdetails(object1)");
		bookdetails  obj3= new bookdetails(obj1);
		obj3.display();
		System.out.println("");
		System.out.println("create object4 without constructor to copy values from object3 to object4");
		System.out.println("object4.code=object3.code;");
		bookdetails  obj4= new bookdetails();
		obj4.bookname=obj3.bookname;
		obj4.author=obj3.author;
		obj4.code=obj3.code;
		obj4.display();
		System.out.println("");
		try
		{
			System.out.println("create a object using clone method");
			System.out.println("obj=(bookdetails)obj2.clone();");
			bookdetails obj=(bookdetails)obj2.clone();
			obj.display();
		}
		catch (CloneNotSupportedException e)   
		{   
		e.printStackTrace();   
		}   
		
		

	}

}
