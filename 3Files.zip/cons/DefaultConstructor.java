package com.test.cons;
class ConstructorKey
{
	String msg;
	int value;
	ConstructorKey ()
	{
		System.out.println("Default Constructor");
		System.out.println("Constructors invoked when the instance of class created");
		System.out.println("Default constructor that displays the default values");
		System.out.println();
		System.out.println("msg : "+msg);
		System.out.println("value : "+value);
	}

}

public class DefaultConstructor 
{
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		ConstructorKey obj= new ConstructorKey ();

	}

}
