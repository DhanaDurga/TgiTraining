package com.test.interfaceexample;
interface display 
{
 void displayinfo();
}

public class InterfaceExample implements display
{
	public void displayinfo()
	
	{
		System.out.println("Hello, Display following information using interface");
		System.out.println(" ");
		System.out.println("The interface in Java is a mechanism to achieve abstraction");
		System.out.println("The Java compiler adds public and abstract keywords before the interface method");
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		InterfaceExample obj =new InterfaceExample();
		obj.displayinfo();
	}

}
