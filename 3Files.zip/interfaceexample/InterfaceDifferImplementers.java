package com.test.interfaceexample;
interface area
{
	void getarea();
	
}
class Rectangle implements area //first implement provider
{
	public void getarea()
	{
		int x=5,y=10;
		System.out.println("The area of Rectangle is :"+(x*y));
	}
}

class Square implements area //second implement provider

{
	public void getarea()
	{
	int x=5;
	System.out.println("The area of Square is :"+(x*x));
	}
}
public class InterfaceDifferImplementers 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Interface area having one method but implementation is provided by different implementation providers");
		System.out.println(" ");
		area obj1=new Rectangle();
		area obj2=new Square();
		obj1.getarea();
		obj2.getarea();

	}

}
