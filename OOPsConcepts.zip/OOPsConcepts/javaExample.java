package com.test.concepts;

import java.util.Scanner;
import java.util.logging.Logger;
//interface declaration
interface accCredit {
	public void credit();
}

interface accSalary {
	default void salary() {
		System.out.println("\n" + "Monthly Salary Amount Rs.20,000 credited on your account");
	}

	public void salaryView();
}

//Abstract class
abstract class abtInterest {
	final int intamount = 125;

	abstract double interest();

	public void view() {
		System.out.println("Interest Amount credit on your account ");
	}

}

class account implements accCredit, accSalary // Multiple Inheritance - implements more then one interface
{
	double salary;
	static Logger log = Logger.getLogger(account.class.getName());

	account(double salary) {
		this.salary = salary;//using this keyword
	}

	public void credit() {
		System.out.println("\n" + "Amount Rs.1000 credited to your Account");
		this.salary = salary + 1000;
		System.out.println("Now Balance of the Account is : " + salary);
	}

	@Override
	public void salaryView() {
		this.salary = salary + 20000;
		System.out.println("Now the Account Balance  is : " + salary);
	}

	public void view()// Method Overriding
	{
		System.out.println("\n" + "Calling view() Overriding method from parent class ");
		System.out.println("Account Holder Amount : " + this.salary);
	}

	public double amount() {
		return this.salary;
	}

}

//Inheritance -extends the parent class
class accdetails extends abtInterest {
	double salary;
	static Logger logs = Logger.getLogger(accdetails.class.getName());

	accdetails(double salary) {
		this.salary = salary;
	}
	public double interest() {

		super.view();//Using super keyword
		this.salary = salary + intamount;
		return salary;
	}

	public void balance() {
		System.out.println("Now the Account balance after the consolidated interest including is : " + salary);
	}
//Method Overloading
	public void balance(double amt) {
		System.out.println("\n" + "Calling balance() Overloading method with parameterised");
		this.salary = salary - amt;
		System.out.println("After withdraw Rs." + amt + " the account balance is : " + salary);
	}
	
	
}

public class javaExample {
	static Logger log = Logger.getLogger(javaExample.class.getName());

	public static void main(String[] args) {
		double salary = 15000.45;
		log.info(
				"Executing the program using INterface and OOPs Concepts -Class ,Object ,Inheritamce , Polymorphism ,Encapsulation and Abstraction");
		log.fine("----------------");
		String myname = "Dhana.M";
		try {
			AccountDetails obj = new AccountDetails(); // Encapsulate Account Details - access using get and set methods
			System.out.println("Enter Your Name that present in ID Proof: ");
			Scanner sc = new Scanner(System.in); // Get the input from user
			String name = sc.next();
			String msg = "Invalid Person";
			boolean a = (name.equals(myname));
			if (a) {

				obj.setAccholder(name);
				obj.setAccno(310024510);
				obj.setBankname("Canara Bank");
				obj.setEmail("dhana@gmail.com");
				obj.setAccbalance(salary);
				System.out.println("\n" + "Encapsulate Account Details - access using get and set methods");
				System.out.println("Account Details" + "\n");
				System.out.println("Account Holder Name : " + obj.getAccholder());
				System.out.println("Bank Name : " + obj.getBankname());
				System.out.println("Account Number : " + obj.getAccno());
				System.out.println("Account Holder Mail-Id: " + obj.getEmail());
				System.out.println("Current Account Balance : " + obj.getAccbalance());
				System.out.println(" ");

			
			salary = obj.getAccbalance();
			accdetails abtobj = new accdetails(salary);
			salary = abtobj.interest();
			abtobj.balance();
			account salobj = new account(salary);
			salobj.salary();
			salobj.salaryView();
			salobj.credit();
			salary = salobj.amount();
			accdetails wdobj = new accdetails(salary);
			wdobj.balance(500);
			} else
				System.out.println(msg);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
