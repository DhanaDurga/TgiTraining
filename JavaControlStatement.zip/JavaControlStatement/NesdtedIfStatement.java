package JavaControlStatement;

import java.util.Scanner;

public class NesdtedIfStatement 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	    System.out.println("Voters document verification to vote :");
	    System.out.println("Enter your age :");
	    int a=sc.nextInt();
	    System.out.println("Enter your AadharNumber :");
	    long b =sc.nextLong();
	   
	    if(a >=18)
	    	{
	    	System.out.println("Your age is : "+ a);
	    	if(b>0L)
	    		{
	    		System.out.println("You are Eligible Person to vote.");
	    		}
	    	else
	    		{
	    		System.out.println("Your Aadhar number was not valid");
	    		}
	    	}// close the first if statement
	    else
	    	System.out.println("You are not Eligible Person to vote.");
	}

}
