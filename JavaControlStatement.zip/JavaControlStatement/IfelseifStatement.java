package JavaControlStatement;
import java.util.Scanner;
public class IfelseifStatement
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number =sc.nextInt();
	  
		if(number>0)
		{  
			System.out.println("POSITIVE");  
		}
		else if(number<0)
		{  
			 System.out.println("NEGATIVE");  
		}
		else
		{  
			System.out.println("ZERO");  
		}
	}
}
