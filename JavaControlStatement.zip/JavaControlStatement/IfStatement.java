package JavaControlStatement;

public class IfStatement
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int age=18;
		
		//check if condition is true or false
		if(age>=18)
		{
			System.out.println("You are eiligible to voting");
		}
		
		

	}

}
