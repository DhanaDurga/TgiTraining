package JavaControlStatement;

public class ControlJump {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i,j,k;
		System.out.println("Print Numbers in Matrix form ");
		aa:
			for( i=1;i<=2;i++)
		{
			bb:
				for(j=1;j<=2;j++)
				{
					cc:
						for(k=1;k<=2;k++)
						{
							System.out.println(i+ " "+ j+" "+k);
						}
				}
	    }
		
		//Using labelled break statement
		System.out.println("\nPrint Numbers using Break statement");
		System.out.println("The inner loop only closed used Break keyword if (j==2)");
		System.out.println("i j k");
		aa:
			for( i=1;i<=2;i++)
		{
			bb:
				for(j=1;j<=2;j++)
				{
					if(j==2)
						break bb;
					cc:
						for(k=1;k<=2;k++)
						{
							System.out.println(i+ " "+ j+" "+k);
							
								
						}
					
				}
	    }
		
		//Using labelled break statement
				System.out.println("\nPrint Numbers using continue statement");
				System.out.println("It continues the inner loop only and skips the remaining code at the specified condition");
				System.out.println("if(k==2)continue from j");
				System.out.println("i j k");
				aa:
					for( i=1;i<=2;i++)
				{
					bb:
						for(j=1;j<=2;j++)
						{
							
								
							cc:
								for(k=1;k<=2;k++)
								{
									if(k==2)
										continue bb;
									System.out.println(i+ " "+ j+" "+k);
									
										
								}
							
						}
			    }
				
		
	
	}

}
