package JavaControlStatement;

public class IfElseStatement 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int age=15;
		
		//check the if condition and display else part when the condition is false
		if(age>=18)
		{
			System.out.println("You are eiligible to voting");
		}
		else
		{
			System.out.println("You are not eiligible to voting");
		}
		
	}
		
}

