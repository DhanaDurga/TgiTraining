package JavaControlStatement;

public class ControlLoopStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int t=0;
		int s=1;
		
		System.out.println("Using for loop statement");
		System.out.println("Print natural numbers upto 15:");
		for(int i=0;i<=15;i++)
		{
			System.out.print(" "+i);
		}
		
		
	System.out.println("\n\nUsing for-each statement");	
	String[] list= {"Eclipse","NetBeans","Intelij IDE","STS"};
	System.out.println("List of IDEs:");
	
	//for-each loop control statement
	for(String name:list)
	{
		
		System.out.println(name);
	}
	
	
	System.out.println("\n\nUsing while loop statement");
	System.out.println("Print even numbers upto 15:");
	System.out.print(t);
	while(t<14)
	{
		t=t+2;
		System.out.print(" "+t);
	}
	

	System.out.println("\n\nUsing do while loop statement");
	System.out.println("Print odd numbers upto 15:");
    do
	{ 
    	System.out.print(" "+s);
		s=s+2;
		
	}while(s<15);
	
	}

}
