package com.test.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class iterateElementsVariousWays 
{

	public static void main(String[] args) 
	{
		
		System.out.println("Display the Student details Using ArrayListList - accept duplicate elements");
		ArrayList<String> alstr=new ArrayList<>();
		alstr.add("Dhana");
		alstr.add("Ammu");
		alstr.add("Dhana");
		ArrayList<Integer> alint =new ArrayList<>(10);
		System.out.println(" ");
		System.out.println("The size of the ArrayListList<String> is : "+alstr.size());
		System.out.println("The size of the ArrayListList<Integer>(10); is : "+alint.size());
		try
		{
			//Print the ArrayList elements using Iterator interface
			System.out.println(" ");
			System.out.println("Print the ArrayList elements without Iteration");
			System.out.println(alstr);
			System.out.println(" ");
			System.out.println("Print the ArrayList elements after Iteration");
			Iterator itr=alstr.iterator();
			while(itr.hasNext())
				System.out.println(itr.next());
			
			//Print the ArrayList elements using for each loop
			System.out.println(" ");
			System.out.println("Print the ArrayList elements using for each loop after get() and set() the value of the elements");
			System.out.println("Changing element \"Dhana\" to\"Dhanam\"- alstr.set(2) : "+alstr.get(0));
			alstr.set(2,"Dhanam");
			for(String name:alstr)
			{
			System.out.println(name);
			}
			
			//Print the ArrayList elements using for loop
			System.out.println(" ");
			System.out.println("Print the ArrayList elements using for loop after adding the elements");
			System.out.println("Adding elements -list.add(),addAll()");
			alstr.add("Dev");
			alstr.add(1,"Bala");
			alint.add(450);
			alint.add(320);
			for(int i=0;i<alstr.size();i++)
			{
				System.out.println(alstr.get(i));
			}
			
			//Print the ArrayList elements using foreach() method 
			System.out.println(" ");
			System.out.println("Print the ArrayList elements using foreach() method after remove the elements from ArrayList");
			System.out.println("Remove elements -list.remove(1) ,remove(Dhanam)");
			alstr.remove(1);
			alstr.remove("Dhanam");
			System.out.println("After removing 1st position and \"Dhanam\" :");
			alstr.forEach(a-> { System.out.println(a);});
			
			//Print the ArrayList elements using forEachRemaining() method
			System.out.println(" ");
			System.out.println("Print the ArrayList<Integer> elements using forEachRemaining() method");
			 Iterator<Integer> itrint=alint.iterator();  
			itrint.forEachRemaining(a->{System.out.println(a);});
			System.out.println(" ");
			
			//Print the ArrayList elements using ListIterator 
			System.out.println("Print the ArrayList alstr elements using ListIterator - element iterates in reverse order ");
			ListIterator<String> litr=alstr.listIterator(alstr.size());
			while(litr.hasPrevious()) {
				String str=litr.previous();
			System.out.println(str);
			}
			while(litr.hasNext()) {
				String str=litr.next();
			System.out.println(str);
			}
			
		}
		catch(Exception e)  
        {  
            System.out.println(e);  
        }  
	}

}
