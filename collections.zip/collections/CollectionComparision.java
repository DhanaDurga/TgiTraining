package com.test.collections;


import java.util.*;

public class CollectionComparision {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> list=new ArrayList<>();
		LinkedList<String> linklist=new LinkedList<>();
		System.out.println("Enter the no of Students:");
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		System.out.println("Enter Students name one by one :");
		for(int i=1;i<=number;i++)
			{
			
			String input=sc.next();
			
			list.add(input);
		}
		System.out.println("Students names are added to the List...");
		System.out.println("List - Allow duplicate values and Maintain insertion order");
		System.out.println(list);
		list.add("Diya");
		list.add(1, "Maxi");
		System.out.println("After adding names Diya ,MAxi(1) : "+list);
		System.out.println("\n"+"Using Iterator :");
		Iterator ite =list.iterator();
		while(ite.hasNext())
		{
			System.out.println(ite.next());
		}
		System.out.println("\n"+"LinkedList -doubly linked list internally to store the elements");
		linklist.addAll(list);
		System.out.println("1.peekFirst() => " +linklist.peekFirst());
		System.out.println("2.pollLast() =>"+linklist.pollLast());
		System.out.println("3.offerFirst(sree) => "+linklist.offerFirst("Sree"));
		System.out.println("Now the LinkedList is : "+linklist);
		System.out.println("\n"+"After Iteration - al.descendingIterator();");
		Iterator<String> itr = linklist.descendingIterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("\n"+"Using ListIterator -iterate the specific number of records");
		ListIterator itre=linklist.listIterator(3);
		while(itre.hasPrevious())
		{
			System.out.println(itre.previous());
		}
		System.out.println("\n"+"Vector - List and Collection Interface");
		Vector<String> vstr=new Vector<>(15);
		vstr.addAll(linklist);
		System.out.println("It's used to Accessing Elements ");
		System.out.println("Top three records sublist(0,3) => "+vstr.subList(0, 3));
		//System.out.println("The default capacity of Veector List is : "+vstr.capacity());
		System.out.println("Present Vector capacity is : "+vstr.capacity());
		vstr.trimToSize();
		System.out.println("After trimToSize(); the Present vector List capacity is : " +vstr.capacity());
		
		System.out.println("\n"+"Stack class is subclass of vector -LIFO Last In First Out using push() and pop() method");
		Stack<String> sobj=new Stack<>();
		sobj.addAll(linklist);
		System.out.println("Search(\"Dhana\"); -the object present in the Stack is =>  "+sobj.search("Dhana"));
		
		System.out.println("\n"+"Set(HashSet) doesn't allow duplicate values and do not maintain any insertion order");
		Set<String> set=new HashSet<>();
		set.addAll(linklist);
		System.out.println(set);
		System.out.println("\n"+"Maintain the insertion order so we move to LinkedHashSet ");
		Set<String> lset=new LinkedHashSet<>();
		lset.addAll(linklist);
		System.out.println("The LinkedHashSet is : "+lset);
		Set<String> tset=new TreeSet<>();
		tset.addAll(linklist);
		System.out.println("\n"+"TreeSet - Sorting the unique elements  ");
		tset.forEach(a->System.out.println(a));
		
	}

}
