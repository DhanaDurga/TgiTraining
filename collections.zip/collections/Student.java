package com.test.collections;


public class Student {
	String name;
	String department;
	final static String clgname ="Anna University";
	double percentage;
	
	public Student(String name, String department ,double percentage) {
		super();
		this.name = name;
		this.department = department;
		//this.clgname = clgname;
		this.percentage = percentage;
	}
	public Student (String name)
	{
		this.name=name;
	}
	public int compareTo(Student st) {

		if (percentage == st.percentage)
			return 0;
		else if (percentage > st.percentage)
			return 1;
		else
			return -1;

	}

	

}
