package com.test.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;


public class CollectionsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Access POJO Class
		HashMap<Integer,Student> map=new HashMap();
		Student s1=new Student("Riya","CSE",9.5);
		Student s2=new Student("Kala","CSE",9.8);
		Student s3=new Student("Siva","IT",8.5);
		Student s4=new Student("Lara","IT",8.7);
		Student s5=new Student("Dev","CSE",9.1);
		
		map.put(12,s1);
		map.put(13, s2);
		map.put(14, s3);
		map.put(15,s4);
		map.put(17, s5);
		
		System.out.println("Create Map <Rollno , Student> : "+"\n");
		 System.out.println("Rollno"+" "+"Name"+" "+"Department"+"  "+"CollegeName"+"       "+"Percentage /10");
		 for(Map.Entry<Integer,Student> stu:map.entrySet())
		 {  
			 int key=stu.getKey();
			 Student stuobj=stu.getValue();
			 
			 //Printing keys and values
			
			 System.out.println(key+"     "+stuobj.name+"     "+stuobj.department+"       "+stuobj.clgname+"     "+stuobj.percentage);
		 }  
		
		System.out.println("\n"+"Get Key values only using keySet() method : "+map.keySet());
		
		//Convert Map values to LIst
		System.out.println("\n"+"Convert Map values to LIst");
		System.out.println("From the StudentDetails only we get the name List : ");
		CollectionsExample obj=new CollectionsExample();
		List<String> listobj= obj.mapValueToList(map);
		System.out.println(listobj);
		
		//Convert Map values to Set - avoid duplicate
		System.out.println("\n"+"Convert Map values to Set - avoid duplicate");
		System.out.println("From the StudentDetails only we get the Department List : ");
		Set<String> setobj= obj.mapValueToSet(map);
		System.out.println(setobj);
		
		
		
	}
	public static List<String> mapValueToList(HashMap<Integer,Student> map)
	{ 
		ArrayList<String> listname = new ArrayList();
		 for(Map.Entry<Integer,Student> stu:map.entrySet())
		 {  
			  Student stuobj=stu.getValue();
			  
			listname.add(stuobj.name);
	   	}
		 return listname;
		 
}
	public static Set<String> mapValueToSet(HashMap<Integer,Student> map)
	{
		Set<String> setname=new TreeSet<>();
		for(Map.Entry<Integer,Student> stu:map.entrySet())
		 {  
			  Student stuobj=stu.getValue();
			  
			setname.add(stuobj.department);
	   	}
		return setname;
	}
	

	
}
