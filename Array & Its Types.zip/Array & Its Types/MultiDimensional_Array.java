package com.test.array;

import java.util.Scanner;

public class MultiDimensional_Array 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("MultiDimensional Array");
		System.out.println("");
		System.out.println("Enter the number for 2Dimensuonal Array");
		Scanner sc =new Scanner(System.in);
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println("Enter the Elements of the Array");
		int[][] arr=new int[n1][n2];
		for(int i=0;i<n1;i++)
			for(int j=0;j<n2;j++)
			{
			 arr[i][j]=sc.nextInt();
			}
		
		System.out.println("The 2-Dimensional Array was :");
		for(int i=0;i<n1;i++)
		{
			for(int j=0;j<n2;j++)
			{
			System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
}
