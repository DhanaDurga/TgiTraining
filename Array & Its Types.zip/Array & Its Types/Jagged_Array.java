package com.test.array;

import java.util.Scanner;

public class Jagged_Array 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter the no of rows of Array");
		Scanner sc=new Scanner(System.in);
		int r=sc.nextInt();
		int arr[][]=new int[r][];
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Enter the no of columns of arr["+i+"]");
			int c=sc.nextInt();
			arr[i]=new int[c];
		}
		System.out.println("Enter the Elements of the Array ");
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
			 arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("The Jagged Array is ");
		for (int i=0; i<arr.length; i++)
		{  
            for (int j=0; j<arr[i].length; j++)
            {  
                System.out.print(arr[i][j]+" ");  
            }  
            System.out.println();//new line 
		}
            
	}

}
