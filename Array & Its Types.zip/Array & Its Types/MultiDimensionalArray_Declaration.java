package com.test.array;

public class MultiDimensionalArray_Declaration
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
int[][] arr= {{1,2},{9,5}};
char [][]brr= {{'a','c'},{'x','A'}};
int crr[][]= {{5,9,3},{2,10,8},{11,21,9}};
char []drr[]= {{'J','A','V','A'},{'P','l','a','t'},{'f','o','r','m'},{'I','n','d','e'}};
System.out.println(" Different way of Multi_Dimensional Array Declaration");
System.out.println("int[][] arr= {{1,2},{9,5}};;");
System.out.println("char [][]brr= {{'a','c'},{'x','A'}};");
System.out.println("int crr[][]= {{5,9,3},{2,10,8},{11,21,9}};");
System.out.println("char []drr[]= {{'J','A','V','A'},{'P','l','a','t'},{'f','o','r','m'},{'I','n','d','e'}};");
System.out.println("Array arr[][]:");
for(int i=0;i<arr.length;i++)
{
	for(int j=0;j<arr.length;j++)
	{
	System.out.print(arr[i][j]+" ");
	}
	System.out.println();
}
System.out.println("Array brr[][]:");
for(int i=0;i<brr.length;i++)
{
	for(int j=0;j<brr.length;j++)
	{
	System.out.print(brr[i][j]+" ");
	}
	System.out.println();
}
System.out.println("Array crr[][]:");
for(int i=0;i<crr.length;i++)
{
	for(int j=0;j<crr.length;j++)
	{
	System.out.print(crr[i][j]+" ");
	}
	System.out.println();
}
System.out.println("Array arr[][]:");
for(int i=0;i<drr.length;i++)
{
	for(int j=0;j<drr.length;j++)
	{
	System.out.print(drr[i][j]+" ");
	}
	System.out.println();
}
}
}
