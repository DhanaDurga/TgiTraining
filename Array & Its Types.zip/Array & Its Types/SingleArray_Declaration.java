package com.test.array;

public class SingleArray_Declaration
{
	public static void main(String args[])
	{
//int arr[]; //declaration of array

//int arr[]=new int[5];// declaratin and instantiation
int arr[]= {5,4,8,3,9};// declaratin , instantiation and initialization
int[] brr= {1,2,3,4,5};
char []crr= {'a','v','f','w','s'};
System.out.println(" Different way of array Declaration");
System.out.println("int arr[]= {5,4,8,3,9};");
System.out.println("int[] brr= {1,2,3,4,5};");
System.out.println("char []crr= {'a','v','f','w','s'};");
for(int i=0;i<=4;i++)
{
	System.out.println(arr[i]+"     "+brr[i]+ "     "+crr[i]);
}



	}
}
