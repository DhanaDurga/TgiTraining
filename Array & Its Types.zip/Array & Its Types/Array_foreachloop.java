package com.test.array;

public class Array_foreachloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char arr[] = { 'a', 'b', 'c', 'd' };
		System.out.println("Using for-each loop on java array");
		for (char i : arr) {

			System.out.println(i);
		}
	}

}
