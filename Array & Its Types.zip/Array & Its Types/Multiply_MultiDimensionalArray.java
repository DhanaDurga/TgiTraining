package com.test.array;

import java.util.Scanner;

public class Multiply_MultiDimensionalArray
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("MultiDimensional Array");
		System.out.println("");
		System.out.println("Enter the number for 2Dimensional Array1");
		Scanner sc =new Scanner(System.in);
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println("Enter the Elements of the Array 1");
		int[][] arr=new int[n1][n2];
		for(int i=0;i<n1;i++)
			for(int j=0;j<n2;j++)
			{
			 arr[i][j]=sc.nextInt();
			}
		
		System.out.println("Enter the number for 2Dimensional Array2");
		int n3=sc.nextInt();
		int n4=sc.nextInt();
		System.out.println("Enter the Elements of the Array 2");
		int[][] arr2=new int[n3][n4];
		for(int i=0;i<n3;i++)
			for(int j=0;j<n4;j++)
			{
			 arr2[i][j]=sc.nextInt();
			}
		System.out.println("The 2-Dimensional Array1 was :");
		for(int i=0;i<n1;i++)
		{
			for(int j=0;j<n2;j++)
			{
			System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("The 2-Dimensional Array2 was :");
		for(int i=0;i<n3;i++)
		{
			for(int j=0;j<n4;j++)
			{
			System.out.print(arr2[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("Multiply-MultiDimensional Array");
		System.out.println("The answer is : ");
		int c[][]=new int[n1][n4];
		
		for(int i=0;i<n1;i++)
		{  
		for(int j=0;j<n4;j++)
		{  
		//c[i][j]=arr[i][j]*arr2[i][j];  
		for(int k=0;k<arr.length;k++)
		{
			c[i][j]+=(arr[i][k]*arr2[k][j]);
			
		}
		System.out.print(c[i][j]+" ");
		}  
		System.out.println();//new line 
	}

}
}