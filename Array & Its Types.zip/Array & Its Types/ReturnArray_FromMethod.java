package com.test.array;
import java.util.Scanner;

public class ReturnArray_FromMethod 
{
	static int[] get()
	{
		System.out.println("Enter the number of elements");
	Scanner sc=new Scanner(System.in);
	int n= sc.nextInt();
	int data[]=new int[n];
	System.out.println("The elements are ");
	for(int i=0;i<n;i++)
	{
		data[i]=sc.nextInt();
	}
	System.out.println("Return Array elements from method get()");
	return data;
	}
	
	static void max(int val[])
	{
		System.out.println(" ");
		System.out.println("Passing array elements to calling method max()");
		int maximum=val[0];
		for(int j=1;j<val.length;j++)
		{
			if(maximum<val[j])
				maximum=val[j];
		}
		System.out.println("The Maximum number from given array of element is : "+maximum);
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("FInd the Maximum number from given array of elements");
		System.out.println(" ");
		int arr[]=get();
		max(arr);

	}

}
