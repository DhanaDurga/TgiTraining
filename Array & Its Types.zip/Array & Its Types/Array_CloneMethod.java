package com.test.array;

public class Array_CloneMethod 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		char arr[]= {'a','f','k','A','R'};
		System.out.println("Copy One Array to another one Using Clone Method");
		System.out.println("Printing original Array");
		for(char j:arr)
			System.out.println(j);
		char c[]= arr.clone();
		System.out.println("Printing Clone of the Array");
		for(int i=0;i<c.length;i++)
			System.out.println(c[i]);
		System.out.println("After Cloning two Array are equal");
		System.out.println("Equal Method : "+arr.equals(c));
		System.out.println("Using Operator : "+ (arr==c));
		
	}

}
