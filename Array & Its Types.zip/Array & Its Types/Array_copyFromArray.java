package com.test.array;

import java.util.Scanner;

public class Array_copyFromArray
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter the size of Single Dimensional Array");
		Scanner sc=new Scanner(System.in);
		int r =sc.nextInt();
		int arr[]=new int[r];
		System.out.println("Enter the elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("The array1 is ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println("");
		System.out.println("Copy the elements of Array1 to Array2 using for loop");
		System.out.println("The Array2 is :");
		int arr2[]=new int[r];
		for(int i=0;i<arr2.length;i++)
		{
		
			arr2[i]=arr[i];//
			System.out.print(arr2[i]+" ");
		}
		
	}
	

}
