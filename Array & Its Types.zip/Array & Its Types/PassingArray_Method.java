package com.test.array;

import java.util.Scanner;

public class PassingArray_Method 
{
	static void min(int value[])
	{	
		System.out.println("Passing array method is invoked");
		int len=value.length;
		System.out.println("Length of the array is : "+len);
		int minimum= value[0];
		for(int j=1;j<value.length;j++)
		{
			if(minimum>value[j])
			
				minimum=value[j];
				
		}
		System.out.println("The minimum value is : "+minimum);
	}
	public static void main(String[] args) 
	{
		try {
			// TODO Auto-generated method stub
			System.out.println("Find the Minimum number from given numbers");
			System.out.println("Enter the number of elements");
			Scanner sc=new Scanner(System.in);
			int n = sc.nextInt();
			System.out.println("Enter the numbers:");
			int data[]=new int[n];
			for(int i=0;i<n;i++)
			{
				
				data[i]=sc.nextInt();
			}
			
			System.out.println();
			System.out.println("Array elements are :");
			
			for(int i=0;i<n;i++)
			{
				
				System.out.println(data[i]);
			}
			System.out.println("Passing Array to a method Min() method");
			min(data);//Passing Array to a method Min() method
			} 
		catch (Exception e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
	}	
}