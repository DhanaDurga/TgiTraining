package databaseToPDF.dynamic;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class CreatePDF_dynamic {

	public static void main(String[] args) throws DocumentException, FileNotFoundException {
		Document document = new Document();
	try
	{
		
		PdfWriter.getInstance(document, (new FileOutputStream("D:\\Dhana\\emp_dynamic.pdf")));
		document.open();
		DBConnection objDBConnection=new DBConnection();
		Connection connection=objDBConnection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="Select empId,fullName,jobDesignation,jobRole,perAnnum_LPA from example";
		ps=connection.prepareStatement(query);
		rs=ps.executeQuery();
		document.add(new Paragraph("empId"+"   "+"FullName"+"  		 "+"JobDesignation"+"    	"+"JobRole"+"   	 "+"PerAnnum in LPA"));
		document.add(new Paragraph("\n"));
		while(rs.next()){
			document.add(new Paragraph(rs.getString("empId")+"      "+rs.getString("fullName")+"   		 "+rs.getString("JobDesignation")+"     	"+rs.getString("JobRole")+"		    "+rs.getString("perAnnum_LPA")));
			document.add(new Paragraph(""));
		}
		document.add(new Paragraph("\n"));
		document.add(new Paragraph("\n"));
		rs=ps.executeQuery();
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println("Data copied");
		PdfPTable table = new PdfPTable(5);
		PdfPCell cell = new PdfPCell(new Phrase("EmpId"));
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("FullName"));
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("JobDesignation"));
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("JobRole"));
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("PerAnnum in LPA"));
		table.addCell(cell);
		table.setHeaderRows(1);
		System.out.println(" table....."+rsmd.getTableName(1));
		String query1="Select empId,fullName,jobDesignation,jobRole,perAnnum_LPA from example";
		ps=connection.prepareStatement(query1,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.TYPE_FORWARD_ONLY);
		rs=ps.executeQuery();
		rs.first();
	do
		{
			String Id=rs.getString("empId");
			String Name=rs.getString("fullName");
			String jobDesignation=rs.getString("jobDesignation");
			String jobRole=rs.getString("jobRole");
			String LPA=rs.getString("perAnnum_LPA");
			table.addCell(Id);
			table.addCell(Name);
			table.addCell(jobDesignation);
			table.addCell(jobRole);
			table.addCell(LPA);
			
			
		}	while(rs.next());	
		
		document.add(table);
		document.close();
		System.out.println("Finished....");
	}

	catch(SQLException e)
	{
		e.printStackTrace();
	}
	finally
	{}
	}

}
