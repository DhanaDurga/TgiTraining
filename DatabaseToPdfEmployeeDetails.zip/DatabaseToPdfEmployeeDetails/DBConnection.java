package databaseToPDF.dynamic;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

	public Connection getConnection() throws FileNotFoundException {
		Connection connection = null;
		System.out.println("Database Connection called");
		Properties dbDetails = new Properties();
		try {
			dbDetails.setProperty("JDBC_DRIVER","com.mysql.cj.jdbc.Driver");
			dbDetails.setProperty("JDBC_URL", "jdbc:mysql://localhost:3306/training");
			dbDetails.setProperty("USER_NAME", "root");
			dbDetails.setProperty("PASSWORD", "root");
			dbDetails.store(new FileWriter("D:\\Dhana\\eclipse-workspace\\CreatePDF\\src\\resources\\db.properties"), "Database Connection Properties Assigned");
			System.out.println("Set properties");
			FileReader reader = new FileReader("D:\\Dhana\\eclipse-workspace\\CreatePDF\\src\\resources\\db.properties");
			dbDetails.load(reader);
			Class.forName(dbDetails.getProperty("JDBC_DRIVER"));
			connection = DriverManager.getConnection(dbDetails.getProperty("JDBC_URL"),
					dbDetails.getProperty("USER_NAME"), dbDetails.getProperty("PASSWORD"));
			System.out.println("Databse Connection - properties called");
		}
		catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
		}
		return connection;
		}
}
